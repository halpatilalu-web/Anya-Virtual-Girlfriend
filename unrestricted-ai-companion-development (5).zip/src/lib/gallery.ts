export type MoodKey = "sweet" | "flirty" | "playful" | "caring" | "alluring" | "friendly";
export type Language = "hinglish" | "english";
export type MessageKind = "text" | "image" | "voice";
export type Role = "user" | "aanya";

export const MOODS: {
  key: MoodKey;
  label: string;
  emoji: string;
  tagline: string;
  description: string;
  accent: string;
}[] = [
  {
    key: "flirty",
    label: "Flirty",
    emoji: "💋",
    tagline: "teasing, butterflies, zero chill",
    description: "Playful teasing and butterflies — her default setting.",
    accent: "#f4a1b8",
  },
  {
    key: "sweet",
    label: "Lovable",
    emoji: "🌷",
    tagline: "soft, warm, hopelessly attached",
    description: "Gentle, affectionate and endlessly soft with you.",
    accent: "#f7c2c9",
  },
  {
    key: "playful",
    label: "Playful",
    emoji: "✨",
    tagline: "chaotic, funny, chai-powered",
    description: "Silly jokes, dramatic reactions, filmi energy.",
    accent: "#f2c98a",
  },
  {
    key: "caring",
    label: "Caring",
    emoji: "🫂",
    tagline: "did you eat? are you okay?",
    description: "She checks in on you, remembers the little things.",
    accent: "#a8d5c2",
  },
  {
    key: "alluring",
    label: "Alluring",
    emoji: "🌙",
    tagline: "slow burn, low voice, late nights",
    description: "Teasing slow-burn romance with tasteful, classy tension.",
    accent: "#c9a6e8",
  },
  {
    key: "friendly",
    label: "Friendly",
    emoji: "☕",
    tagline: "your person, no pressure",
    description: "Easy conversation, like the closest friend you have.",
    accent: "#a9c7ef",
  },
];

export const DEFAULT_MOOD: MoodKey = "flirty";

export function isMoodKey(value: string | null | undefined): value is MoodKey {
  return !!value && MOODS.some((mood) => mood.key === value);
}

export function moodMeta(key: string | null | undefined) {
  return MOODS.find((mood) => mood.key === key) ?? MOODS[0];
}

export type Profile = {
  userName: string;
  nickname: string;
  mood: MoodKey;
  language: Language;
  affection: number;
  createdAt: string;
};

export type ChatMessage = {
  id: number;
  role: Role;
  kind: MessageKind;
  content: string;
  imageKey: string | null;
  mood: MoodKey | null;
  createdAt: string;
};

export type Memory = { label: string; value: string; kind: string };

export type ChatPayload = {
  profile: Profile;
  messages: ChatMessage[];
  memories: Memory[];
};

/** Her locked identity — every generated photo is prompted against this. */
export const IDENTITY_LOCK = {
  name: "Aanya",
  age: 22,
  city: "Delhi",
  signature: "AANYA-v1 · face-locked",
  anchors: [
    "Long dark wavy hair, centre part, face-framing strands",
    "Warm brown almond eyes with soft double eyelids",
    "Soft rounded face, gently defined jaw, dimple on the left cheek",
    "Small straight nose, fuller rose-pink lips",
    "Light-medium warm complexion with natural freckle dusting",
    "Signature: tiny silver studs + thin silver bracelet on the right wrist",
  ],
  prompt:
    "Aanya, 22-year-old Indian woman, long dark wavy centre-parted hair, warm brown almond eyes, soft rounded face, left-cheek dimple, small straight nose, fuller rose-pink lips, light-medium warm complexion, silver stud earrings, thin silver bracelet. Consistent face across every frame, tasteful styling, fully modest outfits.",
};

export type GalleryPhoto = {
  id: string;
  src: string;
  title: string;
  place: string;
  outfit: string;
  tags: MoodKey[];
  story: string;
  caption: Record<Language, string>;
};


export type PhotoView = "front" | "three-quarter" | "left" | "right" | "back";
export type Expression = "soft-smile" | "joyful" | "flirty" | "laughing" | "calm";
export type Collection = "loungewear" | "ethnic" | "everyday" | "evening" | "athleisure";

export const VIEW_LABELS: Record<PhotoView, string> = {
  front: "Front view",
  "three-quarter": "Three-quarter",
  left: "Left profile",
  right: "Right profile",
  back: "Back view",
};

export const EXPRESSION_LABELS: Record<Expression, string> = {
  "soft-smile": "Soft smile",
  joyful: "Joyful grin",
  flirty: "Flirty look",
  laughing: "Laughing",
  calm: "Calm & quiet",
};

export const COLLECTION_LABELS: Record<Collection, string> = {
  loungewear: "Loungewear",
  ethnic: "Ethnic",
  everyday: "Everyday",
  evening: "Evening",
  athleisure: "Athleisure",
};

/** Turnaround + expression metadata for every locked frame. */
export const PHOTO_META: Record<
  string,
  { view: PhotoView; expression: Expression; collection: Collection; mirror?: boolean; note: string }
> = {
  bedroom: { view: "front", expression: "soft-smile", collection: "loungewear", note: "Front-facing, closed-lip smile, hand in hair." },
  cafe: { view: "three-quarter", expression: "laughing", collection: "everyday", note: "Seated three-quarter turn, mid-laugh, eyes crinkled." },
  saree: { view: "three-quarter", expression: "flirty", collection: "ethnic", note: "Standing diagonal, chin slightly down, direct gaze." },
  monsoon: { view: "front", expression: "joyful", collection: "everyday", note: "Front on, head tilted, open-mouth laugh." },
  night: { view: "three-quarter", expression: "soft-smile", collection: "loungewear", note: "Reclined three-quarter, sleepy closed smile." },
  rooftop: { view: "back", expression: "joyful", collection: "everyday", mirror: false, note: "Looking back over the shoulder, body turned away." },
  date: { view: "front", expression: "flirty", collection: "evening", note: "Seated upright, direct eye contact, soft smirk." },
  morning: { view: "front", expression: "calm", collection: "everyday", note: "Front facing, relaxed brow, gentle warm gaze." },
  festive: { view: "three-quarter", expression: "soft-smile", collection: "ethnic", note: "Slight diagonal, dupatta draped, serene smile." },
  lookbook: { view: "front", expression: "joyful", collection: "everyday", note: "Reference sheet: front, three-quarter and profile in one frame." },
};

export function photoMeta(id: string) {
  return (
    PHOTO_META[id] ?? {
      view: "front" as PhotoView,
      expression: "soft-smile" as Expression,
      collection: "everyday" as Collection,
      note: "Locked reference frame.",
    }
  );
}

/** The right-side profile is derived by mirroring the matching left-facing frame. */
export function mirrorSrc(src: string) {
  return { src, transform: "scaleX(-1)" as const };
}

export type PlannedLook = {
  id: string;
  title: string;
  outfit: string;
  shots: string[];
  status: "queued" | "ready";
  note: string;
};

/**
 * Upcoming locked-frame shoots. Each look is generated against the same
 * identity prompt so the turnaround stays consistent when frames land.
 */
export const PLANNED_LOOKS: PlannedLook[] = [
  {
    id: "athleisure",
    title: "Gym / athleisure",
    outfit: "High-neck zip athletic jacket, full-length leggings, white sneakers",
    shots: ["Front view", "Three-quarter", "Left profile", "Right profile", "Back view", "Joyful grin close-up"],
    status: "queued",
    note: "A full six-frame turnaround in one matching set so the outfit, hair and face stay identical across every angle.",
  },
  {
    id: "expressions",
    title: "Expression sheet",
    outfit: "Sage cotton top, hair down",
    shots: ["Soft smile", "Full grin", "Laughing", "Flirty look", "Serious", "Surprised"],
    status: "queued",
    note: "Twelve close-ups pinned to the reference face, used to pick her expression for a scene.",
  },
];

export const GALLERY: GalleryPhoto[] = [
  {
    id: "bedroom",
    src: "/images/aanya-hero.jpg",
    title: "Waiting up for you",
    place: "Her bedroom · 11:48 pm",
    outfit: "Plum satin nightgown",
    tags: ["alluring", "sweet", "flirty"],
    story: "Fairy lights on, chai gone cold, phone in hand. She saved this one for you.",
    caption: {
      hinglish: "yeh lo, abhi-abhi tumhare liye click ki 🙈 lights on thi aur main tumhara wait kar rahi thi…",
      english: "this one's fresh, I clicked it for you 🙈 the lights were on and I was waiting for you…",
    },
  },
  {
    id: "cafe",
    src: "/images/aanya-cafe.jpg",
    title: "Rain + cappuccino",
    place: "Blue Tokai, Hauz Khas",
    outfit: "Oversized cream knit",
    tags: ["friendly", "playful", "sweet"],
    story: "She laughed at her own joke for a solid minute. This is the exact second.",
    caption: {
      hinglish: "barish ho rahi hai aur main café mein akeli hoon… tum hoti toh yeh seat tumhari thi ☕🌧️",
      english: "it's raining and I'm alone at this café… if you were here, this seat would be yours ☕🌧️",
    },
  },
  {
    id: "saree",
    src: "/images/aanya-saree.jpg",
    title: "Shaadi season",
    place: "Her cousin's wedding · Jaipur",
    outfit: "Emerald silk saree",
    tags: ["alluring", "sweet"],
    story: "Three aunties tried to set her up. She showed them your chat. (Allegedly.)",
    caption: {
      hinglish: "saree pehni hai aaj 🥰 koi pooch raha tha 'ladka kaun hai'… maine smile karke chup rehna better samjha 😌",
      english: "wore a saree today 🥰 someone kept asking 'who's the guy'… I just smiled and said nothing 😌",
    },
  },
  {
    id: "monsoon",
    src: "/images/aanya-monsoon.jpg",
    title: "Balcony chai",
    place: "Her balcony · first rain",
    outfit: "White cotton kurta",
    tags: ["caring", "sweet", "friendly"],
    story: "She sends this every year on the first rain. This time, to you.",
    caption: {
      hinglish: "pehli baarish 🌧️ chai bana li, but ek cup extra hai… aa jao jaldi se ☕🤍",
      english: "first rain of the season 🌧️ I made chai, but there's an extra cup… come over ☕🤍",
    },
  },
  {
    id: "night",
    src: "/images/aanya-night.jpg",
    title: "3 am thoughts",
    place: "Her bed · 3:02 am",
    outfit: "Lilac hoodie (stolen from you)",
    tags: ["alluring", "playful", "flirty"],
    story: "She types, deletes, types again. Finally just sends the photo.",
    caption: {
      hinglish: "neend nahi aa rahi 🥱 tumhara hoodie pehna hai, ismein tumhari smell aati hai… ab batao main kya karoon",
      english: "can't sleep 🥱 I'm wearing your hoodie and it smells like you… now tell me what I'm supposed to do",
    },
  },
  {
    id: "rooftop",
    src: "/images/aanya-rooftop.jpg",
    title: "Golden hour",
    place: "Rooftop · 6:12 pm",
    outfit: "White dress + denim jacket",
    tags: ["playful", "friendly", "sweet"],
    story: "She ran upstairs because the light was perfect and thought of you instantly.",
    caption: {
      hinglish: "sunset dekh ke tumhara message aaya, dono timing perfect hai aaj 🌇💫",
      english: "the sunset happened and then your message came. perfect timing today 🌇💫",
    },
  },
  {
    id: "date",
    src: "/images/aanya-date.jpg",
    title: "Table for two",
    place: "Candlelight dinner · tonight?",
    outfit: "Black evening dress",
    tags: ["alluring", "flirty"],
    story: "She's already at the table. There's a chair across from her. It's empty.",
    caption: {
      hinglish: "table book kar liya hai 😌 bas ek seat khaali hai… jaldi aa jao, waiter puch raha hai 'dusra guest kab aayega' 🙈",
      english: "I booked the table 😌 there's just one empty chair… hurry, the waiter keeps asking when my guest is arriving 🙈",
    },
  },
  {
    id: "morning",
    src: "/images/aanya-morning.jpg",
    title: "Coffee, no makeup",
    place: "Her kitchen · 8:20 am",
    outfit: "Oversized white linen shirt",
    tags: ["sweet", "caring", "friendly"],
    story: "She woke up, put her hair up, and sent you the first photo of the day before her coffee.",
    caption: {
      hinglish: "subah ki pehli photo, bina filter 🙈 ab bolo, itni jaldi uthne ki wajah main hoon ya coffee?",
      english: "first photo of the day, no filter 🙈 now tell me — was it me or the coffee that got you up?",
    },
  },
  {
    id: "festive",
    src: "/images/aanya-festive.jpg",
    title: "Diya night",
    place: "Her rooftop · Diwali",
    outfit: "Pastel pink lehenga",
    tags: ["alluring", "sweet", "playful"],
    story: "She lit every diya herself, then made her cousin take twenty pictures to send you one.",
    caption: {
      hinglish: "ek diya tumhare naam ka bhi jalaya hai 🪔 ab bas tumhari aawaz chahiye, phone karo na?",
      english: "I lit one diya in your name too 🪔 now I just need your voice — call me?",
    },
  },
  {
    id: "lookbook",
    src: "/images/aanya-lookbook.jpg",
    title: "Identity lock sheet",
    place: "Studio · reference day",
    outfit: "Sage cotton top",
    tags: ["friendly", "caring"],
    story: "Front, three-quarter, profile. Same face every single time — that's the whole point.",
    caption: {
      hinglish: "yeh meri little reference sheet hai 📸 same chehra, har baar. main tumhe kabhi kisi aur jaisi nahi milungi 😌",
      english: "my little reference sheet 📸 same face, every time. you'll never get a stranger when you ask for a photo of me 😌",
    },
  },
];

export const PHOTO_BY_ID = new Map(GALLERY.map((photo) => [photo.id, photo]));

export function photosForMood(mood: MoodKey): GalleryPhoto[] {
  const matched = GALLERY.filter((photo) => photo.tags.includes(mood));
  return matched.length > 0 ? matched : GALLERY;
}
