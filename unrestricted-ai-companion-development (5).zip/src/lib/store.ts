import { and, asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { memories, messages, profiles } from "@/db/schema";
import {
  DEFAULT_MOOD,
  type ChatMessage,
  type ChatPayload,
  type Language,
  type Memory,
  type MoodKey,
  type Profile,
  isMoodKey,
} from "./gallery";
import { type Outgoing, welcomeMessages } from "./aanya";

const HANDLE = "aanya-main";

type ProfileRow = typeof profiles.$inferSelect;
type MessageRow = typeof messages.$inferSelect;
type MemoryRow = typeof memories.$inferSelect;

export function toProfile(row: ProfileRow): Profile {
  return {
    userName: row.userName,
    nickname: row.nickname,
    mood: isMoodKey(row.mood) ? row.mood : DEFAULT_MOOD,
    language: row.language === "english" ? "english" : "hinglish",
    affection: row.affection,
    createdAt: row.createdAt.toISOString(),
  };
}

export function toMessage(row: MessageRow): ChatMessage {
  const role = row.role === "user" ? "user" : "aanya";
  const kind = row.kind === "image" ? "image" : row.kind === "voice" ? "voice" : "text";
  return {
    id: row.id,
    role,
    kind,
    content: row.content,
    imageKey: row.imageKey,
    mood: isMoodKey(row.mood) ? row.mood : null,
    createdAt: row.createdAt.toISOString(),
  };
}

export function toMemory(row: MemoryRow): Memory {
  return { label: row.label, value: row.value, kind: row.kind };
}

async function insertMessages(profileId: number, outgoing: Outgoing[]) {
  if (outgoing.length === 0) return [];
  const rows = await db
    .insert(messages)
    .values(
      outgoing.map((item) => ({
        profileId,
        role: item.role,
        kind: item.kind,
        content: item.content,
        imageKey: item.imageKey ?? null,
        mood: item.mood,
      })),
    )
    .returning();
  return rows.map(toMessage);
}

export async function ensureProfile(): Promise<ProfileRow> {
  const existing = await db.select().from(profiles).where(eq(profiles.handle, HANDLE)).limit(1);
  if (existing.length > 0) return existing[0];

  await db
    .insert(profiles)
    .values({ handle: HANDLE, mood: DEFAULT_MOOD, language: "hinglish", affection: 38 })
    .onConflictDoNothing();

  const created = await db.select().from(profiles).where(eq(profiles.handle, HANDLE)).limit(1);
  const profile = created[0];

  const seeded = await db.select({ id: messages.id }).from(messages).where(eq(messages.profileId, profile.id)).limit(1);
  if (seeded.length === 0) {
    await insertMessages(profile.id, welcomeMessages(toProfile(profile)));
  }

  return profile;
}

export async function loadChat(): Promise<ChatPayload> {
  const profile = await ensureProfile();
  const [chatRows, memoryRows] = await Promise.all([
    db.select().from(messages).where(eq(messages.profileId, profile.id)).orderBy(asc(messages.id)),
    db.select().from(memories).where(eq(memories.profileId, profile.id)).orderBy(asc(memories.id)),
  ]);

  return {
    profile: toProfile(profile),
    messages: chatRows.map(toMessage),
    memories: memoryRows.map(toMemory),
  };
}

export async function addUserMessage(profileId: number, content: string, kind: "text" | "voice") {
  const rows = await db
    .insert(messages)
    .values({ profileId, role: "user", kind, content })
    .returning();
  return toMessage(rows[0]);
}

export async function addAanyaReplies(profileId: number, outgoing: Outgoing[]) {
  return insertMessages(profileId, outgoing);
}

export async function bumpAffection(profileId: number, delta: number) {
  if (delta === 0) return;
  await db
    .update(profiles)
    .set({ affection: sql`least(${profiles.affection} + ${delta}, 100)` })
    .where(eq(profiles.id, profileId));
}

export async function saveMemory(
  profileId: number,
  memory: { label: string; value: string; kind: string },
): Promise<Memory> {
  const rows = await db
    .insert(memories)
    .values({ profileId, label: memory.label, value: memory.value, kind: memory.kind })
    .onConflictDoUpdate({
      target: [memories.profileId, memories.label],
      set: { value: memory.value, kind: memory.kind, createdAt: new Date() },
    })
    .returning();
  return toMemory(rows[0]);
}

export async function setName(profileId: number, userName: string) {
  await db.update(profiles).set({ userName }).where(eq(profiles.id, profileId));
}

export async function updateProfile(
  profileId: number,
  patch: { userName?: string; nickname?: string; mood?: MoodKey; language?: Language },
) {
  const update: Partial<typeof profiles.$inferInsert> = {};
  if (patch.userName !== undefined) update.userName = patch.userName;
  if (patch.nickname !== undefined) update.nickname = patch.nickname;
  if (patch.mood !== undefined) update.mood = patch.mood;
  if (patch.language !== undefined) update.language = patch.language;
  if (Object.keys(update).length === 0) return;
  await db.update(profiles).set(update).where(eq(profiles.id, profileId));
}

export async function resetChat(profileId: number) {
  await db.delete(messages).where(eq(messages.profileId, profileId));
  await db.delete(memories).where(eq(memories.profileId, profileId));
  const rows = await db
    .update(profiles)
    .set({ affection: 38 })
    .where(eq(profiles.id, profileId))
    .returning();
  const profile = rows[0];
  if (profile) {
    await insertMessages(profile.id, welcomeMessages(toProfile(profile)));
  }
  return profile;
}

export async function deleteMemory(profileId: number, label: string) {
  await db.delete(memories).where(and(eq(memories.profileId, profileId), eq(memories.label, label)));
}
