import { integer, pgTable, serial, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";

/**
 * A single local "you" profile keeps the companion story continuous.
 * Everything she learns about you lives in Postgres so it survives reloads.
 */
export const profiles = pgTable(
  "profiles",
  {
    id: serial("id").primaryKey(),
    handle: text("handle").notNull(),
    userName: text("user_name").notNull().default("jaan"),
    nickname: text("nickname").notNull().default("Aanya"),
    mood: text("mood").notNull().default("flirty"),
    language: text("language").notNull().default("hinglish"),
    affection: integer("affection").notNull().default(38),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("profiles_handle_unique").on(table.handle)],
);

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id")
    .notNull()
    .references(() => profiles.id, { onDelete: "cascade" }),
  role: text("role").notNull(), // "user" | "aanya"
  kind: text("kind").notNull().default("text"), // "text" | "image" | "voice"
  content: text("content").notNull(),
  imageKey: text("image_key"),
  mood: text("mood"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const memories = pgTable(
  "memories",
  {
    id: serial("id").primaryKey(),
    profileId: integer("profile_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    label: text("label").notNull(),
    value: text("value").notNull(),
    kind: text("kind").notNull().default("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("memories_profile_label_unique").on(table.profileId, table.label)],
);

export type ProfileRow = typeof profiles.$inferSelect;
export type MessageRow = typeof messages.$inferSelect;
export type MemoryRow = typeof memories.$inferSelect;
