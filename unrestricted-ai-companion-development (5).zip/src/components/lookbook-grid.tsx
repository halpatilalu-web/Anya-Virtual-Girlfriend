"use client";

import { useMemo, useState } from "react";
import {
  COLLECTION_LABELS,
  EXPRESSION_LABELS,
  GALLERY,
  MOODS,
  VIEW_LABELS,
  photoMeta,
  type Collection,
  type GalleryPhoto,
  type MoodKey,
} from "@/lib/gallery";
import { PhotoViewer } from "./photo-viewer";

type Filter = "all" | MoodKey | Collection;

export function LookbookGrid() {
  const [filter, setFilter] = useState<Filter>("all");
  const [active, setActive] = useState<GalleryPhoto | null>(null);

  const photos = useMemo(() => {
    if (filter === "all") return GALLERY;
    if ((MOODS as { key: string }[]).some((mood) => mood.key === filter)) {
      return GALLERY.filter((photo) => photo.tags.includes(filter as MoodKey));
    }
    return GALLERY.filter((photo) => photoMeta(photo.id).collection === filter);
  }, [filter]);

  return (
    <div>
      <div className="no-scrollbar flex gap-2 overflow-x-auto pb-2">
        <button
          onClick={() => setFilter("all")}
          className={`shrink-0 rounded-full border px-4 py-2 text-xs transition ${
            filter === "all"
              ? "border-rose/60 bg-rose/20 text-cream"
              : "border-white/10 bg-white/5 text-mist hover:border-rose/40"
          }`}
        >
          All frames
        </button>
        {MOODS.map((mood) => (
          <button
            key={mood.key}
            onClick={() => setFilter(mood.key)}
            className={`shrink-0 rounded-full border px-4 py-2 text-xs transition ${
              filter === mood.key
                ? "border-rose/60 bg-rose/20 text-cream"
                : "border-white/10 bg-white/5 text-mist hover:border-rose/40"
            }`}
          >
            {mood.emoji} {mood.label}
          </button>
        ))}
        <span className="mx-1 hidden w-px shrink-0 self-center bg-white/10 sm:block" />
        {(Object.keys(COLLECTION_LABELS) as Collection[]).map((key) => (
          <button
            key={key}
            onClick={() => setFilter(key)}
            className={`shrink-0 rounded-full border px-4 py-2 text-xs transition ${
              filter === key
                ? "border-rose/60 bg-rose/20 text-cream"
                : "border-white/10 bg-white/5 text-mist hover:border-rose/40"
            }`}
          >
            {COLLECTION_LABELS[key]}
          </button>
        ))}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 text-[10px] text-mist/45">
        <span className="rounded-md border border-white/10 px-2 py-1">
          {photos.length} frame{photos.length === 1 ? "" : "s"}
        </span>
        <span>Angles: front · three-quarter · left · right · back</span>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        {photos.map((photo, index) => (
          <button
            key={photo.id}
            onClick={() => setActive(photo)}
            className={`group relative overflow-hidden rounded-2xl border border-white/10 text-left transition hover:-translate-y-1 hover:border-rose/50 ${
              index === 0 ? "col-span-2 row-span-2 lg:col-span-2 lg:row-span-2" : ""
            }`}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={photo.src}
              alt={photo.title}
              loading="lazy"
              className={`w-full object-cover transition duration-700 group-hover:scale-[1.03] ${
                index === 0 ? "h-56 sm:h-72 lg:h-[22rem]" : "h-40 sm:h-48 lg:h-44"
              }`}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#170d15] via-[#170d15]/25 to-transparent opacity-90" />
            <span className="absolute left-3 top-3 rounded-full bg-black/45 px-2 py-1 text-[9px] uppercase tracking-[0.14em] text-rose/90 backdrop-blur">
              {VIEW_LABELS[photoMeta(photo.id).view]}
            </span>
            <div className="absolute inset-x-0 bottom-0 p-3 sm:p-4">
              <p className="font-display text-sm text-cream sm:text-base">{photo.title}</p>
              <p className="mt-0.5 text-[10px] uppercase tracking-[0.18em] text-mist/70">{photo.outfit}</p>
              <p className="mt-0.5 text-[9.5px] text-mist/45">
                {EXPRESSION_LABELS[photoMeta(photo.id).expression]}
              </p>
            </div>
            <span className="absolute right-3 top-3 rounded-full bg-black/40 px-2 py-1 text-[9px] uppercase tracking-[0.16em] text-rose opacity-0 transition group-hover:opacity-100">
              open
            </span>
          </button>
        ))}
      </div>

      <PhotoViewer photo={active} onClose={() => setActive(null)} />
    </div>
  );
}
