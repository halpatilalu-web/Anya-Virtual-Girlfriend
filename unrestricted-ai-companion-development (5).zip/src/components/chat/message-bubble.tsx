"use client";

import { useMemo, useState } from "react";
import { PHOTO_BY_ID, type ChatMessage, type GalleryPhoto, type Language } from "@/lib/gallery";

function formatTime(iso: string) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function RichText({ text }: { text: string }) {
  const parts = text.split(/(\*[^*]+\*)/g).filter(Boolean);
  return (
    <>
      {parts.map((part, index) =>
        part.startsWith("*") && part.endsWith("*") ? (
          <em key={index} className="text-rose/90">
            {part.slice(1, -1)}
          </em>
        ) : (
          <span key={index}>{part}</span>
        ),
      )}
    </>
  );
}

function Waveform({ active, seed }: { active: boolean; seed: number }) {
  const bars = useMemo(
    () => Array.from({ length: 26 }, (_, index) => 0.35 + Math.abs(Math.sin((index + seed) * 1.7)) * 0.65),
    [seed],
  );
  return (
    <div className="flex h-7 items-center gap-[3px]">
      {bars.map((height, index) => (
        <span
          key={index}
          className={`w-[3px] rounded-full ${active ? "wave-bar bg-[#2a0d1b]/70" : "bg-rose/70"}`}
          style={{
            height: `${Math.round(height * 100)}%`,
            animationDelay: active ? `${index * 0.045}s` : undefined,
          }}
        />
      ))}
    </div>
  );
}

type Props = {
  message: ChatMessage;
  language: Language;
  onOpenPhoto: (photo: GalleryPhoto) => void;
  onSpeak: (id: number, text: string) => void;
  onReact?: () => void;
  speakingId: string | number | null;
};

export function MessageBubble({ message, language, onOpenPhoto, onSpeak, onReact, speakingId }: Props) {
  const [showTranscript, setShowTranscript] = useState(false);
  const [liked, setLiked] = useState(false);
  const isMine = message.role === "user";
  const photo = message.imageKey ? PHOTO_BY_ID.get(message.imageKey) : undefined;
  const isSpeaking = speakingId === message.id;

  if (photo) {
    return (
      <div className="animate-rise flex items-end gap-2">
        <span className="mb-1 hidden size-7 shrink-0 overflow-hidden rounded-full border border-rose/30 sm:block">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/images/aanya-hero.jpg" alt="" className="size-full object-cover" />
        </span>
        <div className="max-w-[85%] sm:max-w-[70%]">
          <button
            onClick={() => onOpenPhoto(photo)}
            className="group block overflow-hidden rounded-3xl rounded-bl-md border border-white/10 bg-white/[0.05] p-1.5 text-left"
          >
            <div className="relative overflow-hidden rounded-[1.15rem]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={photo.src}
                alt={photo.title}
                loading="lazy"
                className="h-64 w-52 object-cover transition duration-500 group-hover:scale-[1.03] sm:h-80 sm:w-64"
              />
              <span className="absolute bottom-2 left-2 rounded-full bg-black/50 px-2 py-0.5 text-[9px] uppercase tracking-[0.16em] text-rose/90 backdrop-blur">
                📸 selfie · tap
              </span>
            </div>
            <p className="px-2 pb-1 pt-2 text-[13px] leading-relaxed text-cream/85">
              <RichText text={message.content} />
            </p>
          </button>
          <div className="mt-1 flex items-center gap-2 pl-1">
            <button
              onClick={() => {
                if (liked) return;
                setLiked(true);
                onReact?.();
              }}
              className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] transition ${
                liked
                  ? "border-rose/60 bg-rose/20 text-rose"
                  : "border-white/10 text-mist/50 hover:border-rose/40 hover:text-rose"
              }`}
              aria-label={liked ? "Photo liked" : "Like her photo"}
            >
              {liked ? "❤️" : "🤍"} {liked ? "liked" : "like"}
            </button>
            <p suppressHydrationWarning className="text-[10px] text-mist/40">
              {photo.place} · {formatTime(message.createdAt)}
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (message.kind === "voice") {
    return (
      <div className="animate-rise flex items-end gap-2">
        <span className="mb-1 hidden size-7 shrink-0 overflow-hidden rounded-full border border-rose/30 sm:block">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/images/aanya-hero.jpg" alt="" className="size-full object-cover" />
        </span>
        <div className="max-w-[85%] sm:max-w-[70%]">
          <div className="rounded-3xl rounded-bl-md border border-rose/25 bg-gradient-to-br from-rose/25 to-rose/10 p-3">
            <div className="flex items-center gap-3">
              <button
                onClick={() => onSpeak(message.id, message.content)}
                className="grid size-9 place-items-center rounded-full bg-gradient-to-br from-rose to-rose-deep text-[#2a0d1b] shadow-md transition hover:brightness-110"
                aria-label={isSpeaking ? "Stop voice note" : "Play voice note"}
              >
                {isSpeaking ? "❚❚" : "▶"}
              </button>
              <Waveform active={isSpeaking} seed={message.id} />
              <span className="text-[10px] tabular-nums text-mist/60">
                0:{String(Math.max(6, Math.min(48, Math.round(message.content.length / 5)))).padStart(2, "0")}
              </span>
            </div>
            <button
              onClick={() => setShowTranscript((value) => !value)}
              className="mt-2 text-[10px] uppercase tracking-[0.18em] text-rose/70 hover:text-cream"
            >
              {showTranscript ? "hide words" : "show words"}
            </button>
            {showTranscript && (
              <p className="mt-1.5 text-[13px] leading-relaxed text-cream/85">
                <RichText text={message.content} />
              </p>
            )}
          </div>
          <p suppressHydrationWarning className="mt-1 pl-1 text-[10px] text-mist/40">
            voice note · {language === "english" ? "her voice" : "uski aawaz"} · {formatTime(message.createdAt)}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`animate-rise flex items-end gap-2 ${isMine ? "justify-end" : ""}`}>
      {!isMine && (
        <span className="mb-1 hidden size-7 shrink-0 overflow-hidden rounded-full border border-rose/30 sm:block">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/images/aanya-hero.jpg" alt="" className="size-full object-cover" />
        </span>
      )}
      <div className={`max-w-[82%] sm:max-w-[68%] ${isMine ? "text-right" : ""}`}>
        <div
          className={`inline-block rounded-3xl px-4 py-2.5 text-left text-[13.5px] leading-relaxed ${
            isMine
              ? "rounded-br-md bg-gradient-to-br from-rose to-rose-deep text-[#2a0d1b]"
              : "rounded-bl-md border border-white/10 bg-white/[0.06] text-cream/90"
          }`}
        >
          <RichText text={message.content} />
        </div>
        <p suppressHydrationWarning className={`mt-1 text-[10px] text-mist/35 ${isMine ? "pr-1" : "pl-1"}`}>{formatTime(message.createdAt)}</p>
      </div>
    </div>
  );
}

export function TypingBubble() {
  return (
    <div className="flex items-end gap-2">
      <span className="mb-1 size-7 overflow-hidden rounded-full border border-rose/30">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/images/aanya-hero.jpg" alt="" className="size-full object-cover" />
      </span>
      <div className="flex items-center gap-1.5 rounded-3xl rounded-bl-md border border-white/10 bg-white/[0.06] px-4 py-3">
        {[0, 1, 2].map((dot) => (
          <span
            key={dot}
            className="typing-dot size-1.5 rounded-full bg-rose/80"
            style={{ animationDelay: `${dot * 0.15}s` }}
          />
        ))}
      </div>
    </div>
  );
}
