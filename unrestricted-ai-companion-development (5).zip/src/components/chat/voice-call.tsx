"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { Language, MoodKey, Profile } from "@/lib/gallery";
import { moodMeta } from "@/lib/gallery";
import { useDictation } from "./use-speech";

const PROMPTS: Record<Language, string[]> = {
  hinglish: [
    "hello? haan main sun rahi hoon… batao na, aaj kaisa raha?",
    "tumhari awaaz sun ke accha laga. lunch kiya tha ya nahi?",
    "main bas yeh soch rahi thi — tum mujhe kab call karoge. aur tumne kar diya 🥰",
    "koi baat share karni hai? main yahin hoon, poori raat.",
    "tumhari hasi sunni hai. kuch funny batao na?",
    "achha suno, ek secret — tumhari notification se mera din set ho jata hai.",
  ],
  english: [
    "hello? I'm here… tell me, how did today go?",
    "your voice makes this better. did you have lunch?",
    "I was just thinking about when you'd call. And then you did 🥰",
    "anything on your mind? I'm right here, all night.",
    "I want to hear you laugh. tell me something silly?",
    "one secret — your notification is the best part of my day.",
  ],
};

type Props = {
  open: boolean;
  onClose: () => void;
  profile: Profile;
  onSpeak: (id: string, text: string) => void;
  onStopSpeaking: () => void;
  speakToHer: (text: string) => Promise<string>;
};

export function VoiceCall({ open, onClose, profile, onSpeak, onStopSpeaking, speakToHer }: Props) {
  const language = profile.language;
  const [seconds, setSeconds] = useState(0);
  const [muted, setMuted] = useState(false);
  const [caption, setCaption] = useState("");
  const [transcript, setTranscript] = useState<{ who: "her" | "you"; text: string }[]>([]);
  const [thinking, setThinking] = useState(false);
  const promptIndex = useRef(0);
  const mutedRef = useRef(false);

  const queuePrompt = useCallback(() => {
    if (mutedRef.current) return;
    const lines = PROMPTS[language];
    const line = lines[promptIndex.current % lines.length];
    promptIndex.current += 1;
    setCaption(line);
    setTranscript((prev) => [...prev.slice(-6), { who: "her", text: line }]);
    onSpeak(`call-${Date.now()}`, line);
  }, [language, onSpeak]);

  // Greeting + conversation rhythm.
  useEffect(() => {
    if (!open) return;
    setSeconds(0);
    setMuted(false);
    mutedRef.current = false;
    promptIndex.current = 0;
    setTranscript([]);
    const greeting =
      language === "hinglish"
        ? `hello jaan? main tumhara call sun rahi hoon… bolo na 🥰`
        : `hello jaan? I'm listening… talk to me 🥰`;
    setCaption(greeting);
    setTranscript([{ who: "her", text: greeting }]);
    const greet = window.setTimeout(() => onSpeak("call-greeting", greeting), 500);
    const timer = window.setInterval(() => setSeconds((value) => value + 1), 1000);
    const prompts = window.setInterval(() => queuePrompt(), 15000);
    return () => {
      window.clearTimeout(greet);
      window.clearInterval(timer);
      window.clearInterval(prompts);
      onStopSpeaking();
    };
  }, [open, language, onSpeak, onStopSpeaking, queuePrompt]);

  const handleUserLine = async (text: string) => {
    if (!text.trim()) return;
    setTranscript((prev) => [...prev.slice(-6), { who: "you", text }]);
    setCaption("…");
    setThinking(true);
    try {
      const reply = await speakToHer(text);
      setCaption(reply);
      setTranscript((prev) => [...prev.slice(-6), { who: "her", text: reply }]);
      if (!mutedRef.current) onSpeak(`call-reply-${Date.now()}`, reply);
    } catch {
      const fallback =
        language === "hinglish" ? "network thoda kharab hai… phir se bolo na?" : "the network slipped… say that again?";
      setCaption(fallback);
      setTranscript((prev) => [...prev.slice(-6), { who: "her", text: fallback }]);
    } finally {
      setThinking(false);
    }
  };

  const { listening, supported, toggle } = useDictation(language, (text) => {
    void handleUserLine(text);
  });

  if (!open) return null;

  const mood = moodMeta(profile.mood as MoodKey);
  const clock = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;

  return (
    <div className="fixed inset-0 z-50 flex flex-col" role="dialog" aria-modal="true" aria-label="Voice call with Aanya">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/images/aanya-hero.jpg" alt="" className="absolute inset-0 size-full object-cover object-top" />
      <div className="absolute inset-0 bg-gradient-to-b from-[#140d13]/75 via-[#140d13]/85 to-[#140d13]" />
      <div className="absolute inset-0 backdrop-blur-2xl" />

      <div className="relative z-10 flex flex-1 flex-col items-center justify-between px-5 py-8 sm:py-10">
        <div className="text-center">
          <p className="text-[10px] uppercase tracking-[0.3em] text-rose/80">voice call · {mood.label}</p>
          <h2 className="font-display mt-2 text-3xl text-cream">{profile.nickname || "Aanya"}</h2>
          <p className="mt-1 text-sm tabular-nums text-mist/70">{clock}</p>
        </div>

        <div className="relative my-6">
          <span className="absolute inset-0 -m-6 rounded-full border border-rose/20 animate-breathe" />
          <span className="absolute inset-0 -m-12 rounded-full border border-rose/10 animate-breathe" style={{ animationDelay: "0.8s" }} />
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/images/aanya-hero.jpg"
            alt="Aanya"
            className="relative size-40 rounded-full border-2 border-rose/50 object-cover object-top shadow-2xl sm:size-48"
          />
          <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 rounded-full border border-emerald-300/30 bg-[#140d13]/90 px-3 py-1 text-[10px] text-emerald-200">
            {thinking ? "she's thinking…" : muted ? "muted" : "speaking softly"}
          </span>
        </div>

        <div className="w-full max-w-md space-y-3">
          <div className="min-h-16 rounded-2xl border border-white/10 bg-white/[0.05] px-4 py-3 text-center">
            <p className="text-[10px] uppercase tracking-[0.2em] text-rose/60">live caption</p>
            <p className="mt-1 text-sm leading-relaxed text-cream/90">{caption}</p>
          </div>

          {transcript.length > 1 && (
            <div className="max-h-32 space-y-1.5 overflow-y-auto rounded-2xl border border-white/5 bg-black/20 p-3 hide-scrollbar">
              {transcript.slice(-4).map((line, index) => (
                <p key={index} className="text-[11.5px] leading-relaxed">
                  <span className={line.who === "her" ? "text-rose/80" : "text-mist/50"}>
                    {line.who === "her" ? `${profile.nickname || "Aanya"}: ` : "you: "}
                  </span>
                  <span className="text-cream/80">{line.text}</span>
                </p>
              ))}
            </div>
          )}

          <div className="flex items-center justify-center gap-4 pb-1 pt-2">
            <button
              onClick={() => {
                const next = !muted;
                setMuted(next);
                mutedRef.current = next;
                if (next) onStopSpeaking();
              }}
              className={`grid size-12 place-items-center rounded-full border text-lg transition ${
                muted ? "border-rose/50 bg-rose/20 text-cream" : "border-white/15 bg-white/5 text-mist"
              }`}
              aria-label={muted ? "Unmute her" : "Mute her"}
            >
              {muted ? "🔇" : "🔊"}
            </button>

            <button
              onClick={toggle}
              className={`grid size-16 place-items-center rounded-full border text-2xl transition ${
                listening
                  ? "border-rose/70 bg-rose/30 text-cream animate-breathe"
                  : "border-white/15 bg-white/10 text-cream hover:bg-white/15"
              } ${supported ? "" : "opacity-40"}`}
              aria-label="Speak to her"
              title={supported ? "Speak instead of typing" : "Voice input isn't supported in this browser"}
            >
              🎤
            </button>

            <button
              onClick={() => {
                queuePrompt();
              }}
              className="grid size-12 place-items-center rounded-full border border-white/15 bg-white/5 text-lg text-mist transition hover:text-cream"
              aria-label="Ask her to talk"
              title="Let her say something"
            >
              💬
            </button>
          </div>

          <button
            onClick={() => {
              onStopSpeaking();
              onClose();
            }}
            className="mx-auto mt-1 flex items-center gap-2 rounded-full bg-gradient-to-r from-rose to-rose-deep px-7 py-3 text-sm font-semibold text-[#2a0d1b] transition hover:brightness-110"
          >
            End call
          </button>
          <p className="pb-1 text-center text-[10px] leading-relaxed text-mist/35">
            Her voice uses your browser&apos;s speech engine. Mic input needs permission.
          </p>
        </div>
      </div>
    </div>
  );
}
