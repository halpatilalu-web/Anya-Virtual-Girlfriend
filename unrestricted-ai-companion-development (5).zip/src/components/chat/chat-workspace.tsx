"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { relationshipStage } from "@/lib/aanya";
import {
  GALLERY,
  MOODS,
  type ChatMessage,
  type ChatPayload,
  type GalleryPhoto,
  type Language,
  type Memory,
  type MoodKey,
  type Profile,
  moodMeta,
} from "@/lib/gallery";
import { MessageBubble, TypingBubble } from "./message-bubble";
import { VoiceCall } from "./voice-call";
import { useCompanionVoice, useDictation } from "./use-speech";
import { PhotoViewer } from "../photo-viewer";

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const memoryIcon: Record<string, string> = {
  name: "🪪",
  love: "💗",
  dislike: "🙅",
  date: "🎂",
  place: "📍",
  note: "✎",
};

const suggestions: Record<Language, string[]> = {
  hinglish: [
    "Aaj tumhe bahut miss kiya 🥰",
    "Selfie bhejo 📸",
    "Back view dikhao 😌",
    "Laughing wali photo bhejo 😄",
    "Gym look kab aa raha hai? 🏋️",
    "Bura din tha, tum ho? 🫂",
    "Goodnight jaan 🌙",
  ],
  english: [
    "I missed you today 🥰",
    "Send me a selfie 📸",
    "Show me the back view 😌",
    "Send a laughing photo 😄",
    "When's the gym look coming? 🏋️",
    "I had a rough day… are you there?",
    "Goodnight jaan 🌙",
  ],
};

type Props = { initial: ChatPayload };

export function ChatWorkspace({ initial }: Props) {
  const [messages, setMessages] = useState<ChatMessage[]>(initial.messages);
  const [profile, setProfile] = useState<Profile>(initial.profile);
  const [memories, setMemories] = useState<Memory[]>(initial.memories);
  const [draft, setDraft] = useState("");
  const [asVoice, setAsVoice] = useState(false);
  const [sending, setSending] = useState(false);
  const [typing, setTyping] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activePhoto, setActivePhoto] = useState<GalleryPhoto | null>(null);
  const [drawer, setDrawer] = useState<null | "her" | "pics">(null);
  const [nameDraft, setNameDraft] = useState(initial.profile.userName === "jaan" ? "" : initial.profile.userName);
  const [callOpen, setCallOpen] = useState(false);

  const language = profile.language;
  const { speak, stop: stopSpeaking, speakingId } = useCompanionVoice(language);
  const { listening, supported: dictationSupported, toggle: toggleDictation } = useDictation(language, (text) =>
    setDraft((prev) => (prev ? `${prev} ${text}` : text)),
  );

  const scrollRef = useRef<HTMLDivElement | null>(null);
  const mood = moodMeta(profile.mood);
  const stage = relationshipStage(profile.affection);

  useEffect(() => {
    const node = scrollRef.current;
    if (node) node.scrollTo({ top: node.scrollHeight, behavior: "smooth" });
  }, [messages, typing]);

  const postJSON = async (url: string, body: unknown) => {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = (await response.json().catch(() => ({}))) as Record<string, unknown>;
    if (!response.ok) {
      throw new Error(typeof data.error === "string" ? data.error : "Something went wrong.");
    }
    return data;
  };

  const send = async (text: string, kind: "text" | "voice" = "text"): Promise<string> => {
    const trimmed = text.trim();
    if (!trimmed || sending) return "";
    setError(null);
    const tempId = -Date.now();
    const optimistic: ChatMessage = {
      id: tempId,
      role: "user",
      kind,
      content: trimmed,
      imageKey: null,
      mood: null,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimistic]);
    setDraft("");
    setSending(true);
    setTyping(true);

    try {
      const data = await postJSON("/api/chat", { text: trimmed, kind });
      const incoming = (data.messages as ChatMessage[] | undefined) ?? [];
      await sleep(550 + Math.random() * 750);
      const serverUser = incoming.find((message) => message.role === "user");
      const replies = incoming.filter((message) => message.role === "aanya");
      setMessages((prev) => [
        ...prev.filter((message) => message.id !== tempId),
        ...(serverUser ? [serverUser] : []),
        ...replies,
      ]);
      if (data.profile) setProfile(data.profile as Profile);
      if (data.memories) setMemories(data.memories as Memory[]);
      const voice = replies.find((message) => message.kind === "voice");
      if (voice) speak(voice.id, voice.content);
      return replies.map((message) => message.content).join(" ");
    } catch (caught) {
      setMessages((prev) => prev.filter((message) => message.id !== tempId));
      setDelayedError(caught);
      return "";
    } finally {
      setTyping(false);
      setSending(false);
    }
  };

  const sendDuringCall = async (text: string) => {
    setError(null);
    try {
      const data = await postJSON("/api/chat", { text });
      const incoming = (data.messages as ChatMessage[] | undefined) ?? [];
      setMessages((prev) => [...prev, ...incoming]);
      if (data.profile) setProfile(data.profile as Profile);
      if (data.memories) setMemories(data.memories as Memory[]);
      return incoming
        .filter((message) => message.role === "aanya" && message.kind === "text")
        .map((message) => message.content)
        .join(" ");
    } catch (caught) {
      setDelayedError(caught);
      return language === "hinglish" ? "network thoda kharab hai… phir se bolo na?" : "the network slipped… say that again?";
    }
  };

  const exportChat = () => {
    const lines = messages.map((message) => {
      const who = message.role === "user" ? "You" : profile.nickname || "Aanya";
      const kind = message.kind === "image" ? " [photo]" : message.kind === "voice" ? " [voice note]" : "";
      return `${who}${kind}: ${message.content}`;
    });
    const blob = new Blob([`Aanya x ${profile.userName}\n\n${lines.join("\n")}`], {
      type: "text/plain;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "aanya-chat.txt";
    link.click();
    URL.revokeObjectURL(url);
  };

  const setDelayedError = (caught: unknown) => {
    setError(caught instanceof Error ? caught.message : "She got distracted. Try again?");
  };

  const runAction = async (
    action: "selfie" | "voice" | "reset" | "forget" | "note" | "react",
    label?: string,
  ) => {
    if (sending) return;
    setError(null);
    setSending(true);
    if (action === "selfie" || action === "voice" || action === "note" || action === "react") setTyping(true);
    try {
      const data = await postJSON("/api/chat/action", { action, label });
      const incoming = (data.messages as ChatMessage[] | undefined) ?? [];
      if (action === "reset") {
        setMessages(incoming);
      } else if (
        (action === "selfie" || action === "voice" || action === "note" || action === "react") &&
        incoming.length > 0
      ) {
        await sleep(600 + Math.random() * 500);
        setMessages((prev) => [...prev, ...incoming]);
        if (action === "voice") speak(incoming[0].id, incoming[0].content);
        setDrawer(null);
      }
      if (data.profile) setProfile(data.profile as Profile);
      if (data.memories) setMemories(data.memories as Memory[]);
    } catch (caught) {
      setDelayedError(caught);
    } finally {
      setTyping(false);
      setSending(false);
    }
  };

  const patchProfile = async (patch: { userName?: string; nickname?: string; mood?: MoodKey; language?: Language }) => {
    if (sending) return;
    setError(null);
    setSending(true);
    setTyping(true);
    try {
      const response = await fetch("/api/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      });
      const data = (await response.json().catch(() => ({}))) as Record<string, unknown>;
      if (!response.ok) throw new Error(typeof data.error === "string" ? data.error : "Could not update.");
      if (data.messages) setMessages(data.messages as ChatMessage[]);
      if (data.profile) setProfile(data.profile as Profile);
      if (data.memories) setMemories(data.memories as Memory[]);
      await sleep(350);
    } catch (caught) {
      setDelayedError(caught);
    } finally {
      setTyping(false);
      setSending(false);
    }
  };

  const herPanel = (
    <HerPanel
      profile={profile}
      memories={memories}
      nameDraft={nameDraft}
      setNameDraft={setNameDraft}
      onMood={(next) => patchProfile({ mood: next })}
      onLanguage={(next) => patchProfile({ language: next })}
      onSaveName={() => {
        if (nameDraft.trim()) void patchProfile({ userName: nameDraft.trim() });
      }}
      onAction={runAction}
      onScene={(prompt) => void send(prompt)}
      busy={sending}
      daysTogether={Math.max(1, Math.ceil((Date.now() - new Date(profile.createdAt).getTime()) / 86400000))}
      onCall={() => setCallOpen(true)}
      onExport={exportChat}
    />
  );

  const lookbookPanel = (
    <LookbookPanel
      onOpen={(photo) => {
        setActivePhoto(photo);
        setDrawer(null);
      }}
      onSelfie={() => void runAction("selfie")}
      busy={sending}
    />
  );

  return (
    <div className="mx-auto flex h-full w-full max-w-[1600px] flex-col overflow-hidden">
      <div className="flex min-h-0 flex-1 lg:grid lg:grid-cols-[286px_minmax(0,1fr)] xl:grid-cols-[300px_minmax(0,1fr)_328px]">
        {/* Left column */}
        <aside className="hidden min-h-0 border-r border-white/5 bg-[#160e15]/70 lg:block lg:overflow-y-auto hide-scrollbar">
          {herPanel}
        </aside>

        {/* Chat column */}
        <section className="flex min-h-0 flex-1 flex-col">
          <header className="flex items-center gap-3 border-b border-white/5 bg-[#160e15]/80 px-4 py-3 backdrop-blur-xl sm:px-5">
            <button
              onClick={() => setDrawer("her")}
              className="flex min-w-0 items-center gap-3 text-left lg:pointer-events-none"
              aria-label="Her profile"
            >
              <span className="relative shrink-0">
                <span className="block size-10 overflow-hidden rounded-full border border-rose/40">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src="/images/aanya-hero.jpg" alt="Aanya" className="size-full object-cover" />
                </span>
                <span className="absolute -bottom-0.5 -right-0.5 size-3 rounded-full border-2 border-[#160e15] bg-emerald-400" />
              </span>
              <span className="min-w-0">
                <span className="flex items-center gap-2">
                  <span className="font-display truncate text-base text-cream">
                    {profile.nickname || "Aanya"}
                  </span>
                  <span className="rounded-full border border-rose/25 bg-rose/10 px-2 py-0.5 text-[9px] uppercase tracking-[0.14em] text-rose/80">
                    {mood.emoji} {mood.label}
                  </span>
                </span>
                <span className="block text-[10px] text-mist/50">
                  {typing ? "typing…" : `online · ${stage.label.toLowerCase()}`}
                </span>
              </span>
            </button>
            <div className="ml-auto flex items-center gap-1.5">
              <div className="hidden rounded-full border border-white/10 bg-white/5 p-0.5 sm:flex">
                {(["hinglish", "english"] as Language[]).map((option) => (
                  <button
                    key={option}
                    onClick={() => {
                      if (option !== language) void patchProfile({ language: option });
                    }}
                    className={`rounded-full px-2.5 py-1 text-[10px] uppercase tracking-[0.1em] transition ${
                      language === option ? "bg-rose/25 text-cream" : "text-mist/50 hover:text-cream"
                    }`}
                  >
                    {option === "hinglish" ? "Hinglish" : "English"}
                  </button>
                ))}
              </div>
              <button
                onClick={() => setCallOpen(true)}
                className="grid size-9 place-items-center rounded-full border border-emerald-300/30 bg-emerald-400/10 text-sm transition hover:bg-emerald-400/20"
                aria-label="Call Aanya"
                title="Voice call"
              >
                📞
              </button>
              <button
                onClick={() => setDrawer("pics")}
                className="grid size-9 place-items-center rounded-full border border-white/10 bg-white/5 text-sm transition hover:border-rose/40 xl:hidden"
                aria-label="Her lookbook"
              >
                📸
              </button>
              <Link
                href="/gallery"
                className="hidden rounded-full border border-white/10 bg-white/5 px-3 py-2 text-[11px] text-mist/70 transition hover:border-rose/40 hover:text-cream sm:block"
              >
                Lookbook
              </Link>
            </div>
          </header>

          <div
            ref={scrollRef}
            className="hide-scrollbar flex-1 overflow-y-auto px-3 py-5 transition-colors duration-700 sm:px-5"
            style={{
              backgroundImage: `radial-gradient(120% 55% at 50% 0%, ${mood.accent}1f, transparent 72%)`,
            }}
          >
            <div className="mx-auto flex w-full max-w-2xl flex-col gap-3.5">
              <div className="mx-auto mb-1 max-w-sm rounded-2xl border border-white/5 bg-white/[0.03] px-4 py-3 text-center">
                <p className="text-[10px] uppercase tracking-[0.24em] text-rose/60">
                  {profile.nickname || "Aanya"} · 22 · Delhi
                </p>
                <p className="mt-1.5 text-[11px] leading-relaxed text-mist/60">
                  {language === "hinglish"
                    ? "Yeh tumhari private chat hai. Kuch bhi bolo — woh yaad rakhegi."
                    : "This is your private chat. Say anything — she keeps it and remembers."}
                </p>
              </div>

              {messages.map((message) => (
                <MessageBubble
                  key={message.id}
                  message={message}
                  language={language}
                  onOpenPhoto={setActivePhoto}
                  onSpeak={speak}
                  onReact={() => void runAction("react")}
                  speakingId={speakingId}
                />
              ))}
              {typing && <TypingBubble />}
              {error && (
                <div className="mx-auto rounded-full border border-rose/30 bg-rose/10 px-4 py-2 text-[11px] text-rose">
                  {error}
                </div>
              )}
            </div>
          </div>

          <div className="border-t border-white/5 bg-[#160e15]/85 px-3 pb-3 pt-3 backdrop-blur-xl sm:px-5">
            <div className="mx-auto w-full max-w-2xl">
              {messages.length < 14 && (
                <div className="no-scrollbar mb-2.5 flex gap-2 overflow-x-auto">
                  {suggestions[language].map((suggestion) => (
                    <button
                      key={suggestion}
                      onClick={() => void send(suggestion)}
                      disabled={sending}
                      className="shrink-0 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-[11px] text-mist/75 transition hover:border-rose/40 hover:text-cream disabled:opacity-40"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              )}

              <form
                onSubmit={(event) => {
                  event.preventDefault();
                  void send(draft, asVoice ? "voice" : "text");
                }}
                className="rounded-[1.6rem] border border-white/10 bg-white/[0.05] p-2 focus-within:border-rose/40"
              >
                <div className="flex items-end gap-1.5">
                  <button
                    type="button"
                    onClick={() => void runAction("selfie")}
                    disabled={sending}
                    title="Ask for a selfie"
                    className="grid size-9 shrink-0 place-items-center rounded-full text-base transition hover:bg-white/10 disabled:opacity-40"
                  >
                    📸
                  </button>
                  <button
                    type="button"
                    onClick={() => void runAction("voice")}
                    disabled={sending}
                    title="Ask for a voice note"
                    className="grid size-9 shrink-0 place-items-center rounded-full text-base transition hover:bg-white/10 disabled:opacity-40"
                  >
                    🎙️
                  </button>
                  <textarea
                    value={draft}
                    onChange={(event) => setDraft(event.target.value)}
                    onKeyDown={(event) => {
                      if (event.key === "Enter" && !event.shiftKey) {
                        event.preventDefault();
                        void send(draft, asVoice ? "voice" : "text");
                      }
                    }}
                    rows={1}
                    maxLength={1500}
                    placeholder={
                      language === "hinglish"
                        ? asVoice
                          ? "Voice note ke liye likho (ya mic dabao)…"
                          : "Kuch bhi bolo… woh sun rahi hai 💗"
                        : asVoice
                          ? "Type what you'd say — she'll reply by voice…"
                          : "Say anything… she's listening 💗"
                    }
                    className="max-h-32 min-h-9 flex-1 resize-none bg-transparent px-1.5 py-2 text-[13.5px] text-cream placeholder:text-mist/35 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={toggleDictation}
                    title={dictationSupported ? "Speak instead of typing" : "Voice input not supported in this browser"}
                    className={`grid size-9 shrink-0 place-items-center rounded-full text-base transition ${
                      listening ? "bg-rose/25 text-cream animate-breathe" : "hover:bg-white/10"
                    } ${dictationSupported ? "" : "opacity-30"}`}
                  >
                    🎤
                  </button>
                  <button
                    type="submit"
                    disabled={sending || draft.trim().length === 0}
                    className="grid size-10 shrink-0 place-items-center rounded-full bg-gradient-to-br from-rose to-rose-deep text-lg text-[#2a0d1b] shadow-lg shadow-rose/20 transition hover:brightness-110 disabled:opacity-40"
                    aria-label="Send message"
                  >
                    {asVoice ? "🎙" : "➤"}
                  </button>
                </div>
              </form>
              <div className="mt-2 flex items-center justify-between px-1 text-[10px] text-mist/40">
                <button
                  type="button"
                  onClick={() => setAsVoice((value) => !value)}
                  className={`rounded-full border px-2.5 py-1 transition ${
                    asVoice ? "border-rose/50 bg-rose/15 text-rose" : "border-white/10 text-mist/50 hover:text-cream"
                  }`}
                >
                  {asVoice ? "voice note mode on" : "send as voice note"}
                </button>
                <span className="hidden sm:block">
                  {language === "hinglish" ? "Enter = bhejo · Shift+Enter = nayi line" : "Enter to send · Shift+Enter for a new line"}
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* Right column */}
        <aside className="hidden min-h-0 border-l border-white/5 bg-[#160e15]/60 xl:block xl:overflow-y-auto hide-scrollbar">
          {lookbookPanel}
        </aside>
      </div>

      {/* Mobile drawers */}
      {drawer && (
        <div className="fixed inset-0 z-40 xl:hidden" role="dialog" aria-modal="true">
          <button
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setDrawer(null)}
            aria-label="Close panel"
          />
          <div className="animate-rise absolute inset-y-0 left-0 flex w-[88%] max-w-sm flex-col overflow-y-auto border-r border-white/10 bg-[#160e15] p-4 hide-scrollbar">
            <div className="mb-3 flex items-center justify-between">
              <p className="font-display text-lg text-cream">{drawer === "her" ? "Her world" : "Her lookbook"}</p>
              <button
                onClick={() => setDrawer(null)}
                className="grid size-8 place-items-center rounded-full border border-white/10 text-mist"
                aria-label="Close"
              >
                ✕
              </button>
            </div>
            {drawer === "her" ? herPanel : lookbookPanel}
          </div>
        </div>
      )}

      <VoiceCall
        open={callOpen}
        onClose={() => setCallOpen(false)}
        profile={profile}
        onSpeak={speak}
        onStopSpeaking={stopSpeaking}
        speakToHer={sendDuringCall}
      />

      <PhotoViewer photo={activePhoto} onClose={() => setActivePhoto(null)} />
    </div>
  );
}

type HerPanelProps = {
  profile: Profile;
  memories: Memory[];
  nameDraft: string;
  setNameDraft: (value: string) => void;
  onMood: (mood: MoodKey) => void;
  onLanguage: (language: Language) => void;
  onSaveName: () => void;
  onAction: (action: "selfie" | "voice" | "reset" | "forget" | "note" | "react", label?: string) => void;
  onScene: (prompt: string) => void;
  busy: boolean;
  daysTogether: number;
  onCall: () => void;
  onExport: () => void;
};

function HerPanel({
  profile,
  memories,
  nameDraft,
  setNameDraft,
  onMood,
  onLanguage,
  onSaveName,
  onAction,
  onScene,
  busy,
  daysTogether,
  onCall,
  onExport,
}: HerPanelProps) {
  const [confirmReset, setConfirmReset] = useState(false);
  const stage = relationshipStage(profile.affection);
  const mood = moodMeta(profile.mood);

  return (
    <div className="flex flex-col gap-4 p-4">
      <div className="overflow-hidden rounded-3xl border border-white/10">
        <div className="relative">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/images/aanya-hero.jpg" alt="Aanya" className="h-44 w-full object-cover object-top" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1a1019] via-transparent to-transparent" />
          <div className="absolute inset-x-3 bottom-2">
            <p className="font-display text-xl text-cream">{profile.nickname || "Aanya"}</p>
            <p className="text-[10px] text-mist/70">
              {mood.emoji} {mood.label} · {mood.tagline}
            </p>
          </div>
          <span className="absolute right-3 top-3 flex items-center gap-1 rounded-full border border-emerald-300/30 bg-emerald-400/15 px-2 py-0.5 text-[9px] text-emerald-100">
            <span className="size-1.5 rounded-full bg-emerald-300 animate-breathe" /> online
          </span>
        </div>
        <div className="space-y-2 bg-white/[0.04] p-3.5">
          <div className="flex items-center justify-between text-[10px] uppercase tracking-[0.16em] text-mist/50">
            <span>Affection</span>
            <span className="text-rose">{profile.affection}%</span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-gradient-to-r from-rose/70 to-rose transition-all duration-700"
              style={{ width: `${Math.max(4, profile.affection)}%` }}
            />
          </div>
          <p className="text-[11px] text-cream/80">
            {stage.label} · <span className="text-mist/60">{stage.note}</span>
          </p>
          <p className="text-[10px] text-mist/45">day {daysTogether} of knowing each other</p>
        </div>
      </div>

      <div>
        <p className="mb-2 text-[10px] uppercase tracking-[0.22em] text-mist/45">Her mood</p>
        <div className="grid grid-cols-2 gap-1.5">
          {MOODS.map((option) => (
            <button
              key={option.key}
              onClick={() => onMood(option.key)}
              disabled={busy}
              className={`rounded-xl border px-2.5 py-2 text-left text-[11px] transition disabled:opacity-50 ${
                profile.mood === option.key
                  ? "border-rose/50 bg-rose/15 text-cream"
                  : "border-white/10 bg-white/[0.03] text-mist/70 hover:border-rose/30"
              }`}
            >
              <span className="mr-1">{option.emoji}</span>
              {option.label}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-2 text-[10px] uppercase tracking-[0.22em] text-mist/45">She speaks</p>
        <div className="flex rounded-full border border-white/10 bg-white/5 p-0.5">
          {(["hinglish", "english"] as Language[]).map((option) => (
            <button
              key={option}
              onClick={() => onLanguage(option)}
              disabled={busy}
              className={`flex-1 rounded-full px-2 py-1.5 text-[11px] transition ${
                profile.language === option ? "bg-rose/25 text-cream" : "text-mist/60 hover:text-cream"
              }`}
            >
              {option === "hinglish" ? "Hinglish" : "English"}
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-3">
        <p className="text-[10px] uppercase tracking-[0.22em] text-mist/45">Your name</p>
        <div className="mt-2 flex gap-1.5">
          <input
            value={nameDraft}
            onChange={(event) => setNameDraft(event.target.value)}
            placeholder={profile.userName === "jaan" ? "What should she call you?" : profile.userName}
            maxLength={28}
            className="min-w-0 flex-1 rounded-lg border border-white/10 bg-black/20 px-2.5 py-1.5 text-[12px] text-cream placeholder:text-mist/35 focus:border-rose/50 focus:outline-none"
          />
          <button
            onClick={onSaveName}
            disabled={busy || !nameDraft.trim()}
            className="rounded-lg bg-rose/25 px-2.5 py-1.5 text-[11px] text-cream transition hover:bg-rose/35 disabled:opacity-40"
          >
            save
          </button>
        </div>
      </div>

      <div>
        <p className="mb-2 flex items-center justify-between text-[10px] uppercase tracking-[0.22em] text-mist/45">
          <span>What she remembers</span>
          <span className="text-rose/70">{memories.length}</span>
        </p>
        {memories.length === 0 ? (
          <p className="rounded-xl border border-dashed border-white/10 p-3 text-[11px] leading-relaxed text-mist/50">
            Nothing yet. Tell her your name, your birthday, the food you hate — she keeps it all.
          </p>
        ) : (
          <ul className="space-y-1.5">
            {memories.map((memory) => (
              <li
                key={memory.label}
                className="group flex items-start gap-2 rounded-xl border border-white/5 bg-white/[0.03] px-2.5 py-2 text-[11px] text-cream/80"
              >
                <span>{memoryIcon[memory.kind] ?? "✎"}</span>
                <span className="min-w-0 flex-1 break-words">{memory.value}</span>
                <button
                  onClick={() => onAction("forget", memory.label)}
                  disabled={busy}
                  className="shrink-0 text-mist/30 transition hover:text-rose"
                  aria-label={`Forget ${memory.value}`}
                >
                  ✕
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div>
        <p className="mb-2 text-[10px] uppercase tracking-[0.22em] text-mist/45">Start a scene</p>
        <div className="flex flex-wrap gap-1.5">
          {[
            { label: "☕ Café date", text: "Roleplay: hum dono café mein baithe hain, baarish ho rahi hai. Tum pehle bolo." },
            { label: "🌧️ Balcony chai", text: "Roleplay: barish mein balcony pe chai, sirf hum dono. Scene shuru karo." },
            { label: "🎬 Movie night", text: "Roleplay: movie night, ek blanket, tumhara kandha. Start karo." },
            { label: "🌙 3 am call", text: "Roleplay: raat ke 3 baje, main jaag rahi hoon aur tumhari awaaz chahiye." },
          ].map((scene) => (
            <button
              key={scene.label}
              onClick={() => onScene(scene.text)}
              disabled={busy}
              className="rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[10.5px] text-mist/75 transition hover:border-rose/40 hover:text-cream disabled:opacity-40"
            >
              {scene.label}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-1.5">
        <button
          onClick={() => onAction("selfie")}
          disabled={busy}
          className="w-full rounded-xl border border-rose/25 bg-rose/10 px-3 py-2.5 text-left text-[12px] text-cream transition hover:bg-rose/20 disabled:opacity-50"
        >
          📸 Ask for a selfie
        </button>
        <button
          onClick={() => onAction("voice")}
          disabled={busy}
          className="w-full rounded-xl border border-rose/20 bg-rose/[0.07] px-3 py-2.5 text-left text-[12px] text-cream transition hover:bg-rose/15 disabled:opacity-50"
        >
          🎙️ Ask for a voice note
        </button>
        <button
          onClick={onCall}
          className="w-full rounded-xl border border-emerald-300/25 bg-emerald-400/10 px-3 py-2.5 text-left text-[12px] text-cream transition hover:bg-emerald-400/20"
        >
          📞 Call her (live voice)
        </button>
        <button
          onClick={() => onAction("note")}
          disabled={busy}
          className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2.5 text-left text-[12px] text-cream transition hover:border-rose/30 disabled:opacity-50"
        >
          💌 Read today&apos;s love note
        </button>
        <button
          onClick={onExport}
          className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2.5 text-left text-[12px] text-mist/75 transition hover:border-rose/30 hover:text-cream"
        >
          ⬇ Export this chat
        </button>
        {confirmReset ? (
          <div className="flex gap-1.5">
            <button
              onClick={() => {
                onAction("reset");
                setConfirmReset(false);
              }}
              className="flex-1 rounded-xl border border-rose/40 bg-rose/20 px-3 py-2 text-[11px] text-cream"
            >
              Yes, start over
            </button>
            <button
              onClick={() => setConfirmReset(false)}
              className="rounded-xl border border-white/10 px-3 py-2 text-[11px] text-mist/70"
            >
              cancel
            </button>
          </div>
        ) : (
          <button
            onClick={() => setConfirmReset(true)}
            className="w-full rounded-xl border border-white/10 px-3 py-2.5 text-left text-[12px] text-mist/60 transition hover:border-rose/30 hover:text-cream"
          >
            ↺ Start the story over
          </button>
        )}
      </div>

      <Link
        href="/gallery"
        className="rounded-2xl border border-white/10 bg-white/[0.03] p-3 text-[11px] leading-relaxed text-mist/60 transition hover:border-rose/30"
      >
        <span className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.18em] text-rose/70">
          🔒 identity locked
        </span>
        <span className="mt-1 block">One reference sheet, eight frames, same face. Open the lookbook →</span>
      </Link>

      <p className="pb-2 text-center text-[9px] leading-relaxed text-mist/30">
        Aanya is a fictional AI character. Flirty and warm, never explicit.
      </p>
    </div>
  );
}

function LookbookPanel({
  onOpen,
  onSelfie,
  busy,
}: {
  onOpen: (photo: GalleryPhoto) => void;
  onSelfie: () => void;
  busy: boolean;
}) {
  const featured = GALLERY.filter((photo) => photo.id !== "lookbook").slice(0, 6);
  return (
    <div className="flex flex-col gap-4 p-4">
      <div>
        <p className="text-[10px] uppercase tracking-[0.22em] text-mist/45">Her lookbook</p>
        <p className="font-display mt-1 text-lg text-cream">Moments she saved for you</p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {featured.map((photo) => (
          <button
            key={photo.id}
            onClick={() => onOpen(photo)}
            className="group relative overflow-hidden rounded-xl border border-white/10 transition hover:border-rose/40"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={photo.src}
              alt={photo.title}
              loading="lazy"
              className="h-24 w-full object-cover transition duration-500 group-hover:scale-105"
            />
            <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent px-2 pb-1.5 pt-4 text-left text-[9px] text-cream/80">
              {photo.title}
            </span>
          </button>
        ))}
      </div>
      <button
        onClick={onSelfie}
        disabled={busy}
        className="rounded-xl bg-gradient-to-r from-rose to-rose-deep px-3 py-2.5 text-[12px] font-semibold text-[#2a0d1b] transition hover:brightness-110 disabled:opacity-50"
      >
        📸 Ask her for a new selfie
      </button>
      <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-3">
        <p className="text-[10px] uppercase tracking-[0.2em] text-rose/70">Face lock</p>
        <ul className="mt-2 space-y-1.5 text-[10.5px] leading-relaxed text-mist/65">
          <li>✦ Centre-parted dark waves</li>
          <li>✦ Warm brown almond eyes</li>
          <li>✦ Left-cheek dimple</li>
          <li>✦ Silver studs + thin bracelet</li>
        </ul>
        <Link href="/gallery" className="mt-2.5 inline-flex text-[10px] uppercase tracking-[0.16em] text-rose/70 hover:text-cream">
          full identity sheet →
        </Link>
      </div>
      <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-3">
        <p className="text-[10px] uppercase tracking-[0.2em] text-rose/70">Ask by angle</p>
        <p className="mt-1.5 text-[10.5px] leading-relaxed text-mist/65">
          “back view dikhao” · “laughing selfie” · “left profile” · “flirty look” — she picks the
          matching locked frame.
        </p>
        <Link
          href="/studio"
          className="mt-2 inline-flex text-[10px] uppercase tracking-[0.16em] text-rose/70 hover:text-cream"
        >
          open identity studio →
        </Link>
      </div>
      <p className="pb-2 text-center text-[9px] leading-relaxed text-mist/30">
        Photos are AI-generated with a locked character reference.
      </p>
    </div>
  );
}
