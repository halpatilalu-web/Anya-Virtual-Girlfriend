"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { Language } from "@/lib/gallery";

type RecognitionResultLike = { transcript: string };
type RecognitionLike = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  onresult: ((event: { results: ArrayLike<ArrayLike<RecognitionResultLike>> }) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
};
type RecognitionWindow = {
  SpeechRecognition?: new () => RecognitionLike;
  webkitSpeechRecognition?: new () => RecognitionLike;
};

const localeFor = (language: Language) => (language === "english" ? "en-IN" : "hi-IN");

export function useCompanionVoice(language: Language) {
  const [speakingId, setSpeakingId] = useState<string | number | null>(null);
  const [supported, setSupported] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setSupported("speechSynthesis" in window);
    }, 0);
    return () => {
      window.clearTimeout(timer);
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const stop = useCallback(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    setSpeakingId(null);
  }, []);

  const speak = useCallback(
    (id: string | number, text: string) => {
      if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
      const synth = window.speechSynthesis;
      synth.cancel();
      const utterance = new SpeechSynthesisUtterance(text.replace(/\*/g, "").replace(/[\u{1F300}-\u{1FAFF}]/gu, ""));
      utterance.lang = localeFor(language);
      utterance.rate = 0.94;
      utterance.pitch = 1.12;
      const voices = synth.getVoices();
      const exact = voices.find((voice) => voice.lang === utterance.lang);
      const close = voices.find((voice) => voice.lang.startsWith(utterance.lang.slice(0, 2)));
      const female = voices.find((voice) => /female|woman|priya|veena|heera|samantha|google uk english female/i.test(voice.name));
      utterance.voice = exact ?? close ?? female ?? null;
      utterance.onend = () => setSpeakingId(null);
      utterance.onerror = () => setSpeakingId(null);
      setSpeakingId(id);
      synth.speak(utterance);
    },
    [language],
  );

  return { speak, stop, speakingId, supported };
}

export function useDictation(language: Language, onText: (text: string) => void) {
  const [listening, setListening] = useState(false);
  const [supported, setSupported] = useState(false);
  const recognitionRef = useRef<RecognitionLike | null>(null);
  const callbackRef = useRef(onText);

  useEffect(() => {
    callbackRef.current = onText;
  }, [onText]);

  useEffect(() => {
    const w = window as unknown as RecognitionWindow;
    const timer = window.setTimeout(() => {
      setSupported(Boolean(w.SpeechRecognition ?? w.webkitSpeechRecognition));
    }, 0);
    return () => {
      window.clearTimeout(timer);
      recognitionRef.current?.stop();
    };
  }, []);

  const toggle = useCallback(() => {
    if (typeof window === "undefined") return;
    if (listening) {
      recognitionRef.current?.stop();
      setListening(false);
      return;
    }
    const w = window as unknown as RecognitionWindow;
    const Ctor = w.SpeechRecognition ?? w.webkitSpeechRecognition;
    if (!Ctor) return;
    const recognition = new Ctor();
    recognition.lang = localeFor(language);
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.onresult = (event) => {
      let text = "";
      for (let index = 0; index < event.results.length; index += 1) {
        const alternative = event.results[index]?.[0];
        if (alternative?.transcript) text += `${alternative.transcript} `;
      }
      if (text.trim()) callbackRef.current(text.trim());
    };
    recognition.onerror = () => setListening(false);
    recognition.onend = () => setListening(false);
    recognition.start();
    recognitionRef.current = recognition;
    setListening(true);
  }, [language, listening]);

  return { listening, supported, toggle };
}
