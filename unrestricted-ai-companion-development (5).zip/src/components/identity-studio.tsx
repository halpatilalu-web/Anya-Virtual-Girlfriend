"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import {
  COLLECTION_LABELS,
  EXPRESSION_LABELS,
  GALLERY,
  IDENTITY_LOCK,
  PHOTO_META,
  PLANNED_LOOKS,
  VIEW_LABELS,
  photoMeta,
  type Collection,
  type Expression,
  type GalleryPhoto,
  type PhotoView,
} from "@/lib/gallery";
import { PhotoViewer } from "@/components/photo-viewer";

const VIEW_ORDER: PhotoView[] = ["front", "three-quarter", "left", "right", "back"];
const EXPRESSION_ORDER: Expression[] = ["soft-smile", "joyful", "flirty", "laughing", "calm"];

function frameFor(view: PhotoView): { photo: GalleryPhoto; mirrored: boolean } {
  const pickId: Record<PhotoView, string> = {
    front: "bedroom",
    "three-quarter": "saree",
    left: "cafe",
    right: "cafe",
    back: "rooftop",
  };
  if (view === "right") {
    // Right-side profile is the mirrored left-facing frame in the turnaround.
    const photo = GALLERY.find((item) => item.id === "saree") ?? GALLERY[0];
    return { photo, mirrored: true };
  }
  const photo = GALLERY.find((item) => item.id === pickId[view]) ?? GALLERY[0];
  return { photo, mirrored: false };
}

export function IdentityStudio() {
  const [tab, setTab] = useState<"turnaround" | "expressions" | "wardrobe">("turnaround");
  const [view, setView] = useState<PhotoView>("front");
  const [expression, setExpression] = useState<Expression>("joyful");
  const [collection, setCollection] = useState<Collection | "all">("all");
  const [active, setActive] = useState<GalleryPhoto | null>(null);

  const expressionFrame = useMemo(
    () =>
      GALLERY.find((photo) => photoMeta(photo.id).expression === expression) ??
      GALLERY.find((photo) => photoMeta(photo.id).expression === "soft-smile") ??
      GALLERY[0],
    [expression],
  );

  const wardrobe = useMemo(
    () =>
      collection === "all"
        ? GALLERY
        : GALLERY.filter((photo) => photoMeta(photo.id).collection === collection),
    [collection],
  );

  const activeFrame = frameFor(view);

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center gap-3 rounded-2xl border border-rose/20 bg-rose/[0.07] px-4 py-3">
        <span className="rounded-full border border-rose/40 bg-rose/15 px-2.5 py-0.5 text-[9px] uppercase tracking-[0.16em] text-rose">
          next drop
        </span>
        <p className="text-[11.5px] leading-relaxed text-cream/80">
          <strong className="font-medium text-cream">Gym / athleisure turnaround</strong> — front,
          three-quarter, left, right and back in one matching set
          <span className="text-mist/50"> · queued for the next frame batch</span>
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {(
          [
            ["turnaround", "Turnaround"],
            ["expressions", "Expressions"],
            ["wardrobe", "Wardrobe"],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`rounded-full border px-4 py-2 text-xs transition ${
              tab === key
                ? "border-rose/60 bg-rose/20 text-cream"
                : "border-white/10 bg-white/5 text-mist hover:border-rose/40"
            }`}
          >
            {label}
          </button>
        ))}
        <span className="ml-auto hidden items-center gap-2 text-[10px] uppercase tracking-[0.18em] text-mist/50 sm:flex">
          🔒 {IDENTITY_LOCK.signature}
        </span>
      </div>

      {tab === "turnaround" && (
        <div className="mt-6 grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
          <div className="panel relative overflow-hidden rounded-[2rem] p-2.5">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              key={`${activeFrame.photo.id}-${view}`}
              src={activeFrame.photo.src}
              alt={`${IDENTITY_LOCK.name} — ${VIEW_LABELS[view]}`}
              className="h-[24rem] w-full rounded-[1.6rem] object-cover object-top transition sm:h-[32rem]"
              style={activeFrame.mirrored ? { transform: "scaleX(-1)" } : undefined}
            />
            <div className="absolute inset-x-5 top-5 flex items-center justify-between">
              <span className="rounded-full border border-white/20 bg-black/40 px-3 py-1 text-[10px] uppercase tracking-[0.2em] text-cream backdrop-blur">
                {VIEW_LABELS[view]}
              </span>
              <span className="rounded-full border border-emerald-300/30 bg-emerald-400/15 px-3 py-1 text-[10px] text-emerald-100 backdrop-blur">
                face lock verified
              </span>
            </div>
            <div className="absolute inset-x-4 bottom-4 rounded-2xl border border-white/15 bg-[#1b1019]/85 px-4 py-3 backdrop-blur">
              <p className="text-[11px] leading-relaxed text-cream/80">{photoMeta(activeFrame.photo.id).note}</p>
              {activeFrame.mirrored && (
                <p className="mt-1 text-[10px] text-rose/80">
                  Right profile shown as a mirror of the locked left-facing frame — same features, opposite turn.
                </p>
              )}
            </div>
          </div>

          <div>
            <p className="text-[10px] uppercase tracking-[0.24em] text-mist/45">Pick an angle</p>
            <div className="mt-3 space-y-2">
              {VIEW_ORDER.map((option) => {
                const frame = frameFor(option);
                return (
                  <button
                    key={option}
                    onClick={() => setView(option)}
                    className={`flex w-full items-center gap-3 rounded-2xl border p-2.5 text-left transition ${
                      view === option
                        ? "border-rose/50 bg-rose/12"
                        : "border-white/10 bg-white/[0.03] hover:border-rose/30"
                    }`}
                  >
                    <span className="block size-12 shrink-0 overflow-hidden rounded-xl border border-white/10">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={frame.photo.src}
                        alt=""
                        className="size-full object-cover object-top"
                        style={frame.mirrored ? { transform: "scaleX(-1)" } : undefined}
                      />
                    </span>
                    <span className="min-w-0">
                      <span className="block text-[12.5px] text-cream">{VIEW_LABELS[option]}</span>
                      <span className="block truncate text-[10.5px] text-mist/50">
                        {frame.photo.outfit}
                      </span>
                    </span>
                    {frame.mirrored && (
                      <span className="ml-auto rounded-full border border-white/10 px-2 py-0.5 text-[9px] uppercase tracking-[0.12em] text-mist/50">
                        mirror
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
            <div className="mt-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
              <p className="text-[10px] uppercase tracking-[0.2em] text-rose/70">Locked anchors</p>
              <ul className="mt-2 space-y-1.5 text-[11px] leading-relaxed text-mist/70">
                {IDENTITY_LOCK.anchors.slice(0, 4).map((anchor) => (
                  <li key={anchor}>✦ {anchor}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {tab === "expressions" && (
        <div className="mt-6">
          <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
            {EXPRESSION_ORDER.map((option) => (
              <button
                key={option}
                onClick={() => setExpression(option)}
                className={`shrink-0 rounded-full border px-4 py-2 text-xs transition ${
                  expression === option
                    ? "border-rose/60 bg-rose/20 text-cream"
                    : "border-white/10 bg-white/5 text-mist hover:border-rose/40"
                }`}
              >
                {EXPRESSION_LABELS[option]}
              </button>
            ))}
          </div>

          <div className="mt-5 grid gap-6 lg:grid-cols-[0.95fr_1.05fr] lg:items-center">
            <div className="panel overflow-hidden rounded-[2rem] p-2.5">
              <div className="relative overflow-hidden rounded-[1.6rem]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={expressionFrame.src}
                  alt={`${IDENTITY_LOCK.name} — ${EXPRESSION_LABELS[expression]}`}
                  className="h-[22rem] w-full object-cover object-top transition sm:h-[28rem]"
                  style={{ transform: "scale(1.35)", objectPosition: "50% 22%" }}
                />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#150d14] via-[#150d14]/40 to-transparent p-4">
                  <p className="text-[10px] uppercase tracking-[0.2em] text-rose/80">Expression study</p>
                  <p className="font-display mt-1 text-xl text-cream">{EXPRESSION_LABELS[expression]}</p>
                  <p className="mt-1 text-[11px] text-mist/60">{photoMeta(expressionFrame.id).note}</p>
                </div>
              </div>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-[0.24em] text-mist/45">Frames with this mood</p>
              <div className="mt-3 grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                {GALLERY.filter((photo) => photoMeta(photo.id).expression === expression).map((photo) => (
                  <button
                    key={photo.id}
                    onClick={() => setActive(photo)}
                    className="group overflow-hidden rounded-xl border border-white/10 text-left transition hover:border-rose/40"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={photo.src}
                      alt={photo.title}
                      className="h-28 w-full object-cover object-top transition group-hover:scale-105"
                    />
                    <span className="block px-2 py-1.5 text-[10px] text-mist/60">{photo.title}</span>
                  </button>
                ))}
              </div>
              <div className="mt-4 rounded-2xl border border-rose/20 bg-rose/[0.07] p-4">
                <p className="text-[10px] uppercase tracking-[0.2em] text-rose/80">Coming in her next shoot</p>
                <p className="mt-2 text-sm leading-relaxed text-cream/85">
                  A twelve-expression sheet — soft smile, full grin, laughing, flirty, serious and
                  surprised — all rendered against the same reference face so you can pick her
                  expression for any scene.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === "wardrobe" && (
        <div className="mt-6">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setCollection("all")}
              className={`rounded-full border px-4 py-2 text-xs transition ${
                collection === "all"
                  ? "border-rose/60 bg-rose/20 text-cream"
                  : "border-white/10 bg-white/5 text-mist hover:border-rose/40"
              }`}
            >
              All · {GALLERY.length}
            </button>
            {(Object.keys(COLLECTION_LABELS) as Collection[]).map((key) => {
              const count = GALLERY.filter((photo) => photoMeta(photo.id).collection === key).length;
              return (
                <button
                  key={key}
                  onClick={() => setCollection(key)}
                  className={`rounded-full border px-4 py-2 text-xs transition ${
                    collection === key
                      ? "border-rose/60 bg-rose/20 text-cream"
                      : "border-white/10 bg-white/5 text-mist hover:border-rose/40"
                  }`}
                >
                  {COLLECTION_LABELS[key]} · {count}
                </button>
              );
            })}
          </div>

          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {wardrobe.map((photo) => {
              const meta = PHOTO_META[photo.id];
              const mirrored = photo.id === "saree";
              return (
                <button
                  key={photo.id}
                  onClick={() => setActive(photo)}
                  className="group overflow-hidden rounded-2xl border border-white/10 text-left transition hover:-translate-y-1 hover:border-rose/40"
                >
                  <div className="relative">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={photo.src}
                      alt={photo.title}
                      loading="lazy"
                      className="h-44 w-full object-cover object-top transition duration-500 group-hover:scale-105"
                      style={mirrored ? { transform: "scaleX(-1)" } : undefined}
                    />
                    <span className="absolute left-2 top-2 rounded-full bg-black/50 px-2 py-0.5 text-[9px] uppercase tracking-[0.14em] text-rose/90 backdrop-blur">
                      {VIEW_LABELS[meta.view]}
                    </span>
                  </div>
                  <div className="p-2.5">
                    <p className="text-[12px] text-cream">{photo.title}</p>
                    <p className="text-[10px] text-mist/50">{COLLECTION_LABELS[meta.collection]} · {EXPRESSION_LABELS[meta.expression]}</p>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="mt-8 grid gap-4 md:grid-cols-2">
            {PLANNED_LOOKS.map((look) => (
              <div key={look.id} className="rounded-2xl border border-dashed border-white/15 bg-white/[0.02] p-5">
                <div className="flex items-center justify-between">
                  <p className="font-display text-lg text-cream">{look.title}</p>
                  <span className="rounded-full border border-rose/30 bg-rose/10 px-2.5 py-0.5 text-[9px] uppercase tracking-[0.16em] text-rose/90">
                    queued
                  </span>
                </div>
                <p className="mt-1 text-[11px] text-mist/55">{look.outfit}</p>
                <p className="mt-3 text-xs leading-relaxed text-mist/70">{look.note}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {look.shots.map((shot) => (
                    <span
                      key={shot}
                      className="rounded-md border border-white/10 bg-black/20 px-2 py-1 text-[9.5px] uppercase tracking-[0.1em] text-mist/50"
                    >
                      {shot}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <p className="mt-4 text-[11px] leading-relaxed text-mist/45">
            Frames are generated in batches against one locked reference sheet. Queued looks keep the
            same face, hair part and signature details — only the outfit and angle change. Ask for a
            selfie in chat and she sends from whichever set is ready.
          </p>
        </div>
      )}

      <PhotoViewer photo={active} onClose={() => setActive(null)} />

      <div className="mt-10 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-5">
        <div>
          <p className="text-[10px] uppercase tracking-[0.2em] text-rose/70">Try it in chat</p>
          <p className="mt-1 text-sm text-cream/85">
            Ask for a front view, a laughing selfie, or her gym look.
          </p>
        </div>
        <Link
          href="/chat"
          className="rounded-full bg-gradient-to-r from-rose to-rose-deep px-5 py-2.5 text-sm font-semibold text-[#2a0d1b] transition hover:brightness-110"
        >
          Ask Aanya →
        </Link>
      </div>
    </div>
  );
}
