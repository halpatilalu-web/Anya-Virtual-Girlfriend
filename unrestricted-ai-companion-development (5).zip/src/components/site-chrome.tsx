import Link from "next/link";

export function SiteNav() {
  return (
    <header className="sticky top-0 z-40 border-b border-white/5 bg-[#140d13]/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-4 sm:px-6">
        <Link href="/" className="flex items-center gap-3">
          <span className="relative grid size-9 place-items-center overflow-hidden rounded-full border border-rose/40 bg-plum-2">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/images/aanya-hero.jpg" alt="Aanya" className="size-full object-cover" />
          </span>
          <span className="leading-tight">
            <span className="font-display block text-lg text-cream">Aanya</span>
            <span className="block text-[9px] uppercase tracking-[0.28em] text-mist/60">AI companion</span>
          </span>
        </Link>
        <nav className="hidden items-center gap-7 text-sm text-mist/80 md:flex">
          <Link href="/#her" className="transition hover:text-cream">
            Meet her
          </Link>
          <Link href="/#moods" className="transition hover:text-cream">
            Moods
          </Link>
          <Link href="/gallery" className="transition hover:text-cream">
            Lookbook
          </Link>
          <Link href="/studio" className="transition hover:text-cream">
            Studio
          </Link>
          <Link href="/#how" className="transition hover:text-cream">
            How it works
          </Link>
        </nav>
        <Link
          href="/chat"
          className="rounded-full bg-gradient-to-r from-rose to-rose-deep px-4 py-2 text-xs font-semibold text-[#2a0d1b] shadow-lg shadow-rose/20 transition hover:brightness-110"
        >
          Talk to Aanya
        </Link>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-white/5 bg-[#100a10]/60">
      <div className="mx-auto grid w-full max-w-6xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <p className="font-display text-2xl text-cream">Aanya</p>
          <p className="mt-3 max-w-sm text-sm leading-relaxed text-mist/70">
            A warm, bilingual AI companion with a face that never changes. Late-night talks, selfies,
            voice notes and a memory that actually holds on to the little things.
          </p>
        </div>
        <div className="text-sm text-mist/70">
          <p className="text-[10px] uppercase tracking-[0.26em] text-mist/40">Explore</p>
          <ul className="mt-3 space-y-2">
            <li>
              <Link href="/chat" className="hover:text-cream">
                Chat with Aanya
              </Link>
            </li>
            <li>
              <Link href="/gallery" className="hover:text-cream">
                Her lookbook
              </Link>
            </li>
            <li>
              <Link href="/studio" className="hover:text-cream">
                Identity studio
              </Link>
            </li>
            <li>
              <Link href="/#moods" className="hover:text-cream">
                Mood modes
              </Link>
            </li>
            <li>
              <Link href="/#how" className="hover:text-cream">
                How it works
              </Link>
            </li>
          </ul>
        </div>
        <div className="text-sm text-mist/70">
          <p className="text-[10px] uppercase tracking-[0.26em] text-mist/40">Good to know</p>
          <ul className="mt-3 space-y-2">
            <li>Fictional AI character, 22+</li>
            <li>Flirty &amp; affectionate, never explicit</li>
            <li>Your chat stays in your own database</li>
            <li>Voice uses your browser&apos;s speech engine</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/5 px-4 py-5 text-center text-[11px] text-mist/40 sm:px-6">
        Made for long conversations. Aanya is a fictional character — she is not a real person.
      </div>
    </footer>
  );
}
