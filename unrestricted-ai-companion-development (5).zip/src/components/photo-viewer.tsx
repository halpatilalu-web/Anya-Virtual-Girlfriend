"use client";

import { useEffect } from "react";
import type { GalleryPhoto } from "@/lib/gallery";

export function PhotoViewer({ photo, onClose }: { photo: GalleryPhoto | null; onClose: () => void }) {
  useEffect(() => {
    if (!photo) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = previous;
    };
  }, [photo, onClose]);

  if (!photo) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#0d070c]/85 p-4 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-label={photo.title}
      onClick={onClose}
    >
      <div
        className="panel animate-rise relative flex max-h-[92vh] w-full max-w-4xl flex-col overflow-hidden rounded-[28px] md:flex-row"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="relative flex-1 bg-black/40">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={photo.src}
            alt={photo.title}
            className="h-full max-h-[46vh] w-full object-cover md:max-h-[80vh]"
          />
          <span className="absolute left-4 top-4 rounded-full border border-white/15 bg-black/45 px-3 py-1 text-[10px] uppercase tracking-[0.22em] text-rose">
            {photo.id} · face locked
          </span>
        </div>
        <div className="flex w-full flex-col gap-4 p-6 md:max-w-sm md:overflow-y-auto">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="font-display text-2xl text-cream">{photo.title}</h3>
              <p className="mt-1 text-xs uppercase tracking-[0.2em] text-mist/70">{photo.place}</p>
            </div>
            <button
              onClick={onClose}
              className="grid size-9 shrink-0 place-items-center rounded-full border border-white/15 text-mist transition hover:border-rose/60 hover:text-cream"
              aria-label="Close photo"
            >
              ✕
            </button>
          </div>
          <p className="text-sm leading-relaxed text-cream/75">{photo.story}</p>
          <div className="rounded-2xl border border-rose/20 bg-rose/10 p-4">
            <p className="text-[10px] uppercase tracking-[0.22em] text-rose/80">Her caption</p>
            <p className="mt-2 text-sm leading-relaxed text-cream/90">“{photo.caption.hinglish}”</p>
          </div>
          <div className="mt-auto space-y-2 text-xs text-mist/80">
            <p>
              <span className="text-mist/50">Outfit · </span>
              {photo.outfit}
            </p>
            <p>
              <span className="text-mist/50">Identity · </span>AANYA-v1 face-locked reference
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
