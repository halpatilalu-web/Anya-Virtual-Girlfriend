import Link from "next/link";
import { ChatWorkspace } from "@/components/chat/chat-workspace";
import { loadChat } from "@/lib/store";
import { type ChatPayload } from "@/lib/gallery";

export const dynamic = "force-dynamic";

export default async function ChatPage() {
  let payload: ChatPayload | null = null;
  try {
    payload = await loadChat();
  } catch (error) {
    console.error("chat page load failed", error);
  }

  return (
    <div className="flex h-[100dvh] flex-col overflow-hidden">
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-white/5 bg-[#140d13]/85 px-4 backdrop-blur-xl sm:px-5">
        <Link href="/" className="flex items-center gap-2">
          <span className="block size-6 overflow-hidden rounded-full border border-rose/40">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/images/aanya-hero.jpg" alt="" className="size-full object-cover" />
          </span>
          <span className="font-display text-sm text-cream">Aanya</span>
          <span className="hidden rounded-full border border-white/10 px-2 py-0.5 text-[9px] uppercase tracking-[0.16em] text-mist/50 sm:block">
            private chat
          </span>
        </Link>
        <nav className="flex items-center gap-4 text-[11px] text-mist/60">
          <Link href="/" className="transition hover:text-cream">
            home
          </Link>
          <Link href="/gallery" className="transition hover:text-cream">
            lookbook
          </Link>
        </nav>
      </header>

      <div className="min-h-0 flex-1">
        {payload ? (
          <ChatWorkspace initial={payload} />
        ) : (
          <div className="grid h-full place-items-center px-6 text-center">
            <div className="panel max-w-md rounded-3xl p-8">
              <p className="font-display text-2xl text-cream">She&apos;s just fixing her hair…</p>
              <p className="mt-3 text-sm leading-relaxed text-mist/70">
                The chat database didn&apos;t answer. Refresh in a moment, or head home and come back.
              </p>
              <Link
                href="/"
                className="mt-6 inline-flex rounded-full bg-gradient-to-r from-rose to-rose-deep px-5 py-2.5 text-sm font-semibold text-[#2a0d1b]"
              >
                Back home
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
