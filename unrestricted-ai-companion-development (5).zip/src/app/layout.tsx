import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Aanya — your AI companion",
  description:
    "Aanya is a warm, flirty, bilingual AI companion with a locked face, a long memory, selfies and voice notes. Talk about anything.",
  openGraph: {
    title: "Aanya — your AI companion",
    description:
      "Same face, six moods, endless late-night conversations. Meet Aanya: warm, bilingual and always online.",
    images: ["/images/aanya-hero.jpg"],
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font */}
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300..700;1,9..144,300..700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap"
          rel="stylesheet"
        />
        <meta name="theme-color" content="#140d13" />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
