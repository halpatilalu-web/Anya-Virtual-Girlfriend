import Link from "next/link";
import { GALLERY, IDENTITY_LOCK } from "@/lib/gallery";
import { LookbookGrid } from "@/components/lookbook-grid";
import { SiteFooter, SiteNav } from "@/components/site-chrome";

const consistency = [
  {
    title: "One reference sheet",
    body: "Front, three-quarter and profile shots are generated first. Every later frame is prompted against that same reference.",
  },
  {
    title: "Locked facial anchors",
    body: "Hair part, eye shape, nose, lip shape and the left-cheek dimple are written into every prompt as fixed attributes.",
  },
  {
    title: "Same signature details",
    body: "Silver studs and the thin silver bracelet on her right wrist appear in every photo — small proof it's still her.",
  },
  {
    title: "Outfits change, face doesn't",
    body: "Satin, cotton, saree or hoodie — the wardrobe changes with the scene while the identity stays frozen.",
  },
];

export default function GalleryPage() {
  return (
    <div className="relative">
      <SiteNav />
      <main className="mx-auto w-full max-w-6xl px-4 pb-20 pt-12 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full border border-rose/30 bg-rose/10 px-3 py-1.5 text-[10px] uppercase tracking-[0.2em] text-rose">
              🔒 identity locked · {IDENTITY_LOCK.signature}
            </span>
            <h1 className="font-display mt-5 text-4xl leading-tight text-cream sm:text-5xl">
              Her lookbook, same face <span className="italic text-rose">every time.</span>
            </h1>
            <p className="mt-4 text-sm leading-relaxed text-mist/75 sm:text-base">
              Everyday frames from Aanya&apos;s life — rain, weddings, late nights and one very empty
              dinner chair. Ask her for a selfie in chat and she&apos;ll send one from this same set of
              days, with the same face.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link
              href="/studio"
              className="rounded-full border border-white/15 bg-white/5 px-5 py-3 text-sm text-cream transition hover:border-rose/50"
            >
              Open identity studio
            </Link>
            <Link
              href="/chat"
              className="rounded-full bg-gradient-to-r from-rose to-rose-deep px-6 py-3 text-sm font-semibold text-[#2a0d1b] shadow-xl shadow-rose/20 transition hover:brightness-110"
            >
              Ask her for a photo →
            </Link>
          </div>
        </div>

        <div className="mt-10">
          <LookbookGrid />
        </div>

        {/* Identity sheet */}
        <section className="mt-16 grid gap-8 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
          <div className="panel overflow-hidden rounded-[2rem] p-2.5">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/images/aanya-lookbook.jpg"
              alt="Aanya identity reference sheet"
              className="w-full rounded-[1.6rem] object-cover"
            />
            <div className="flex items-center justify-between px-3 py-2.5 text-[10px] uppercase tracking-[0.18em] text-mist/50">
              <span>reference sheet · front / three-quarter / profile</span>
              <span className="text-rose/70">AANYA-v1</span>
            </div>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-[0.3em] text-rose/70">Character consistency</p>
            <h2 className="font-display mt-4 text-3xl leading-tight text-cream sm:text-4xl">
              How her face stays hers.
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-mist/75">
              Every photo is an original AI-generated image of a fictional character. Her face is
              pinned to one written identity so she never shows up looking like a different person.
            </p>
            <div className="mt-6 grid gap-2 sm:grid-cols-2">
              {IDENTITY_LOCK.anchors.map((anchor) => (
                <div
                  key={anchor}
                  className="rounded-xl border border-white/5 bg-white/[0.03] p-3 text-[11.5px] leading-relaxed text-mist/75"
                >
                  <span className="mr-1.5 text-rose">✦</span>
                  {anchor}
                </div>
              ))}
            </div>
            <details className="mt-5 rounded-2xl border border-white/10 bg-black/20 p-4 text-xs text-mist/60">
              <summary className="cursor-pointer text-[10px] uppercase tracking-[0.2em] text-rose/70">
                view locked identity prompt
              </summary>
              <p className="mt-3 leading-relaxed">{IDENTITY_LOCK.prompt}</p>
            </details>
          </div>
        </section>

        <section className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {consistency.map((item) => (
            <div key={item.title} className="soft-card rounded-2xl p-5">
              <h3 className="text-sm font-semibold text-cream">{item.title}</h3>
              <p className="mt-2 text-xs leading-relaxed text-mist/65">{item.body}</p>
            </div>
          ))}
        </section>

        <section className="panel mt-16 flex flex-wrap items-center justify-between gap-6 rounded-[2rem] p-8">
          <div>
            <p className="font-display text-2xl text-cream">
              {GALLERY.length} frames. One her.
            </p>
            <p className="mt-2 max-w-lg text-sm text-mist/70">
              Tell her which mood you&apos;re in and the photos change with it — soft and warm, playful,
              or a slow-burn late-night kind of pretty.
            </p>
          </div>
          <Link
            href="/chat"
            className="rounded-full border border-rose/40 bg-rose/15 px-6 py-3 text-sm text-cream transition hover:bg-rose/25"
          >
            Open the chat →
          </Link>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
