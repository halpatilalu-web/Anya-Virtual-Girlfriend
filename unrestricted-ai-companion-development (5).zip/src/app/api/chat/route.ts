import { composeTurn, detectLanguage, memoryAck, type Outgoing } from "@/lib/aanya";
import {
  addAanyaReplies,
  addUserMessage,
  bumpAffection,
  ensureProfile,
  loadChat,
  saveMemory,
  setName,
  toProfile,
} from "@/lib/store";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  try {
    const payload = await loadChat();
    return Response.json(payload);
  } catch (error) {
    console.error("chat GET failed", error);
    return Response.json({ error: "Could not load your chat." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { text?: unknown; kind?: unknown };
    const text = typeof body.text === "string" ? body.text.trim() : "";
    const asVoice = body.kind === "voice";

    if (!text) {
      return Response.json({ error: "Write something for her first." }, { status: 400 });
    }
    if (text.length > 1500) {
      return Response.json({ error: "That's a little too long for one message." }, { status: 400 });
    }

    const row = await ensureProfile();
    const profile = toProfile(row);
    const language = detectLanguage(text, profile.language);

    const userMessage = await addUserMessage(row.id, text, asVoice ? "voice" : "text");
    const turn = composeTurn(text, profile, language);

    const outgoing: Outgoing[] = [...turn.outgoing];
    if (turn.memories && turn.memories.length > 0) {
      for (const memory of turn.memories) {
        await saveMemory(row.id, memory);
      }
      if (turn.nameUpdate) await setName(row.id, turn.nameUpdate);
      outgoing.push({
        role: "aanya",
        kind: "text",
        content: turn.memories.map((memory) => memoryAck(memory, language)).join(" "),
        imageKey: null,
        mood: profile.mood,
      });
    }

    const replies = await addAanyaReplies(row.id, outgoing);
    await bumpAffection(row.id, turn.affectionDelta);

    const next = await loadChat();

    return Response.json({
      messages: [userMessage, ...replies],
      profile: next.profile,
      memories: next.memories,
      language,
    });
  } catch (error) {
    console.error("chat POST failed", error);
    return Response.json({ error: "She got distracted for a second. Try again?" }, { status: 500 });
  }
}
