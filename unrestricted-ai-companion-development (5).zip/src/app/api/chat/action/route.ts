import { REACTION_LINES, NOTE_LINES, buildPhotoTurn, buildVoiceTurn } from "@/lib/aanya";
import type { Language } from "@/lib/gallery";
import {
  addAanyaReplies,
  bumpAffection,
  deleteMemory,
  ensureProfile,
  loadChat,
  resetChat,
  toProfile,
} from "@/lib/store";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { action?: unknown; label?: unknown };
    const action = typeof body.action === "string" ? body.action : "";
    const row = await ensureProfile();
    const profile = toProfile(row);
    const language: Language = profile.language;

    if (action === "selfie") {
      const outgoing = buildPhotoTurn(profile, language);
      const messages = await addAanyaReplies(row.id, [outgoing]);
      await bumpAffection(row.id, 1);
      const next = await loadChat();
      return Response.json({ ...next, messages });
    }

    if (action === "voice") {
      const outgoing = buildVoiceTurn(profile, language);
      const messages = await addAanyaReplies(row.id, [outgoing]);
      await bumpAffection(row.id, 1);
      const next = await loadChat();
      return Response.json({ ...next, messages });
    }

    if (action === "react") {
      const line = REACTION_LINES[language][Math.floor(Math.random() * REACTION_LINES[language].length)];
      const messages = await addAanyaReplies(row.id, [
        { role: "aanya", kind: "text", content: line, imageKey: null, mood: profile.mood },
      ]);
      await bumpAffection(row.id, 1);
      const next = await loadChat();
      return Response.json({ ...next, messages });
    }

    if (action === "note") {
      const line = NOTE_LINES[language][Math.floor(Math.random() * NOTE_LINES[language].length)];
      const messages = await addAanyaReplies(row.id, [
        { role: "aanya", kind: "text", content: line, imageKey: null, mood: profile.mood },
      ]);
      await bumpAffection(row.id, 1);
      const next = await loadChat();
      return Response.json({ ...next, messages });
    }

    if (action === "forget") {
      const label = typeof body.label === "string" ? body.label : "";
      if (label) await deleteMemory(row.id, label);
      const next = await loadChat();
      return Response.json({ ...next, messages: [] });
    }

    if (action === "reset") {
      await resetChat(row.id);
      const next = await loadChat();
      return Response.json(next);
    }

    return Response.json({ error: "Unknown action." }, { status: 400 });
  } catch (error) {
    console.error("chat action failed", error);
    return Response.json({ error: "That didn't work. Try again?" }, { status: 500 });
  }
}
