import { moodIntro } from "@/lib/aanya";
import { DEFAULT_MOOD, isMoodKey, type Language, type MoodKey } from "@/lib/gallery";
import {
  addAanyaReplies,
  bumpAffection,
  ensureProfile,
  loadChat,
  setName,
  updateProfile,
} from "@/lib/store";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function PATCH(request: Request) {
  try {
    const body = (await request.json()) as {
      userName?: unknown;
      nickname?: unknown;
      mood?: unknown;
      language?: unknown;
    };

    const row = await ensureProfile();
    const currentMood: MoodKey = isMoodKey(row.mood) ? row.mood : DEFAULT_MOOD;
    const patch: { userName?: string; nickname?: string; mood?: MoodKey; language?: Language } = {};

    if (typeof body.userName === "string") {
      const value = body.userName.trim().slice(0, 28);
      if (value.length >= 1) {
        patch.userName = value;
        await setName(row.id, value);
      }
    }
    if (typeof body.nickname === "string") {
      const value = body.nickname.trim().slice(0, 24);
      if (value.length >= 1) patch.nickname = value;
    }
    if (typeof body.mood === "string" && isMoodKey(body.mood)) {
      patch.mood = body.mood;
    }
    if (body.language === "hinglish" || body.language === "english") {
      patch.language = body.language;
    }

    await updateProfile(row.id, patch);

    if (patch.mood) {
      const language: Language = patch.language ?? (row.language === "english" ? "english" : "hinglish");
      await addAanyaReplies(row.id, [
        {
          role: "aanya",
          kind: "text",
          content: moodIntro(patch.mood, language),
          imageKey: null,
          mood: patch.mood,
        },
      ]);
      await bumpAffection(row.id, 1);
    }

    if (patch.nickname) {
      const language: Language = patch.language ?? (row.language === "english" ? "english" : "hinglish");
      await addAanyaReplies(row.id, [
        {
          role: "aanya",
          kind: "text",
          content:
            language === "hinglish"
              ? `${patch.nickname}? okay yeh naam mujhe pasand hai 😌 ab ise mat badalna`
              : `${patch.nickname}? okay, I like that 😌 don't change it now`,
          imageKey: null,
          mood: patch.mood ?? currentMood,
        },
      ]);
    }

    const payload = await loadChat();
    return Response.json(payload);
  } catch (error) {
    console.error("profile PATCH failed", error);
    return Response.json({ error: "Could not update your profile." }, { status: 500 });
  }
}
