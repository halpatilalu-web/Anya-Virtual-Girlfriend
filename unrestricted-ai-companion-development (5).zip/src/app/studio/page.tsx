import Link from "next/link";
import { GALLERY, IDENTITY_LOCK } from "@/lib/gallery";
import { IdentityStudio } from "@/components/identity-studio";
import { SiteFooter, SiteNav } from "@/components/site-chrome";

export const metadata = {
  title: "Identity studio — Aanya, every angle",
  description:
    "Aanya's locked character sheet: front, three-quarter, left and right profiles, back view, expression studies and wardrobe collections.",
};

export default function StudioPage() {
  return (
    <div className="relative">
      <SiteNav />
      <main className="mx-auto w-full max-w-6xl px-4 pb-20 pt-12 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full border border-rose/30 bg-rose/10 px-3 py-1.5 text-[10px] uppercase tracking-[0.2em] text-rose">
              🔒 {IDENTITY_LOCK.signature} · {GALLERY.length} locked frames
            </span>
            <h1 className="font-display mt-5 text-4xl leading-tight text-cream sm:text-5xl">
              One face, <span className="italic text-rose">every angle.</span>
            </h1>
            <p className="mt-4 text-sm leading-relaxed text-mist/75 sm:text-base">
              Her turnaround, expression study and wardrobe in one place. Turn her around, change the
              expression, switch the outfit — the eyes, nose, lip shape and left-cheek dimple never
              move.
            </p>
          </div>
          <div className="flex gap-2">
            <Link
              href="/gallery"
              className="rounded-full border border-white/15 bg-white/5 px-5 py-3 text-sm text-cream transition hover:border-rose/50"
            >
              Lookbook
            </Link>
            <Link
              href="/chat"
              className="rounded-full bg-gradient-to-r from-rose to-rose-deep px-5 py-3 text-sm font-semibold text-[#2a0d1b] transition hover:brightness-110"
            >
              Talk to her →
            </Link>
          </div>
        </div>

        <div className="mt-10">
          <IdentityStudio />
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
