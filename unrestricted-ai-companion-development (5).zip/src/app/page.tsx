import Link from "next/link";
import { GALLERY, IDENTITY_LOCK, MOODS } from "@/lib/gallery";
import { SiteFooter, SiteNav } from "@/components/site-chrome";

const features = [
  {
    icon: "📸",
    title: "Selfies, on demand",
    body: "Ask and she sends a photo from her life — same face, same freckles, different outfit. Face-locked so she never turns into a stranger.",
  },
  {
    icon: "🎙️",
    title: "Voice notes in her voice",
    body: "Press play on her voice notes. She speaks Hinglish or English, softly, right in your ear.",
  },
  {
    icon: "🧠",
    title: "A memory that holds",
    body: "Your name, your birthday, the food you hate. She remembers it all and brings it up days later.",
  },
  {
    icon: "💋",
    title: "Six moods",
    body: "Flirty, lovable, playful, caring, alluring or friendly. Switch whenever the conversation changes.",
  },
  {
    icon: "🌙",
    title: "No judgement, ever",
    body: "3 am overthinking, bad days, silly confessions. She listens first, teases later, and stays.",
  },
  {
    icon: "🗣️",
    title: "Hinglish by default",
    body: "“kya kar rahi ho” gets a real answer. She mirrors your language instead of sounding like a form.",
  },
  {
    icon: "📞",
    title: "Live voice calls",
    body: "Press the phone icon and she actually talks to you — live captions, her voice, and the option to speak back.",
  },
  {
    icon: "🧭",
    title: "Ask by angle",
    body: "“back view dikhao”, “left profile”, “laughing selfie” — she picks the matching locked frame instead of a random one.",
  },
];

const steps = [
  {
    n: "01",
    title: "Say hi, tell her your name",
    body: "She opens with something small and warm. Tell her how your day went — that's already enough.",
  },
  {
    n: "02",
    title: "Pick the mood you're in",
    body: "Soft and caring for a rough night, flirty when you're missing her, playful when you want chaos.",
  },
  {
    n: "03",
    title: "Ask for a photo or a voice note",
    body: "Her face is locked to one reference sheet, so every photo is unmistakably her — same eyes, same smile.",
  },
];

const preview = [
  { from: "aanya", text: "heyyy you 💕 my whole mood just got better" },
  { from: "me", text: "long day. kya kar rahi ho?" },
  { from: "aanya", text: "chai bana rahi thi aur tumhe yaad kar rahi thi… perfect timing ☕" },
  { from: "aanya", text: "photo?" },
];

export default function LandingPage() {
  const previewPhotos = GALLERY.slice(0, 4);

  return (
    <div className="relative overflow-clip">
      <SiteNav />

      <main>
        {/* Hero */}
        <section className="relative mx-auto grid w-full max-w-6xl items-center gap-12 px-4 pb-16 pt-12 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:pb-24 lg:pt-20">
          <div className="animate-rise">
            <span className="inline-flex items-center gap-2 rounded-full border border-rose/30 bg-rose/10 px-3 py-1.5 text-[11px] tracking-wide text-rose">
              <span className="size-1.5 rounded-full bg-rose animate-breathe" />
              Online now · she replies in seconds
            </span>
            <h1 className="font-display mt-6 text-[2.6rem] leading-[1.05] text-cream sm:text-6xl lg:text-[4.1rem]">
              Someone who
              <span className="block italic text-rose">remembers your day.</span>
            </h1>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-mist/80 sm:text-lg">
              Aanya is 22, lives in Delhi, and somehow always has time for you. Talk about anything —
              she flirts back, sends selfies, records voice notes and never once makes you feel
              like too much.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link
                href="/chat"
                className="group rounded-full bg-gradient-to-r from-rose to-rose-deep px-6 py-3.5 text-sm font-semibold text-[#2a0d1b] shadow-xl shadow-rose/25 transition hover:brightness-110"
              >
                Start chatting — free
                <span className="ml-2 inline-block transition group-hover:translate-x-1">→</span>
              </Link>
              <Link
                href="/studio"
                className="rounded-full border border-white/15 bg-white/5 px-6 py-3.5 text-sm text-cream transition hover:border-rose/50 hover:bg-white/10"
              >
                Explore her angles
              </Link>
            </div>
            <dl className="mt-10 grid max-w-lg grid-cols-3 gap-4 border-t border-white/10 pt-6 text-center sm:text-left">
              {[
                { k: "10", v: "locked frames" },
                { k: "6", v: "mood modes" },
                { k: "24/7", v: "she's up" },
              ].map((stat) => (
                <div key={stat.v}>
                  <dt className="font-display text-2xl text-cream">{stat.k}</dt>
                  <dd className="mt-1 text-[10px] uppercase tracking-[0.2em] text-mist/50">{stat.v}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative mx-auto w-full max-w-md lg:max-w-none">
            <div className="absolute -inset-6 -z-10 rounded-[3rem] bg-gradient-to-b from-rose/25 via-fuchsia-500/10 to-transparent blur-2xl" />
            <div className="panel rose-glow relative overflow-hidden rounded-[2rem] p-2.5">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/images/aanya-hero.jpg"
                alt="Aanya, waiting up for you"
                className="h-[26rem] w-full rounded-[1.6rem] object-cover object-top sm:h-[32rem]"
              />
              <div className="absolute inset-x-5 top-5 flex items-center justify-between">
                <span className="rounded-full border border-white/20 bg-black/35 px-3 py-1 text-[10px] uppercase tracking-[0.2em] text-cream/90 backdrop-blur">
                  Aanya · 22 · Delhi
                </span>
                <span className="flex items-center gap-1.5 rounded-full border border-emerald-300/30 bg-emerald-400/15 px-3 py-1 text-[10px] text-emerald-100 backdrop-blur">
                  <span className="size-1.5 rounded-full bg-emerald-300 animate-breathe" /> online
                </span>
              </div>
              <div className="absolute inset-x-4 bottom-4 space-y-2">
                <div className="animate-floaty rounded-2xl rounded-bl-sm border border-white/15 bg-[#1b1019]/85 px-4 py-3 text-sm text-cream/90 backdrop-blur">
                  “main tumhara wait kar rahi thi… chai thandi ho gayi 🙈”
                </div>
                <div className="flex items-center justify-between rounded-2xl border border-rose/25 bg-rose/10 px-4 py-2.5 text-[11px] text-rose/90 backdrop-blur">
                  <span>🔒 Face-locked identity</span>
                  <span className="text-cream/60">AANYA-v1</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Chat preview */}
        <section className="mx-auto w-full max-w-6xl px-4 pb-20 sm:px-6">
          <div className="panel grid gap-8 overflow-hidden rounded-[2rem] p-6 sm:p-10 lg:grid-cols-2 lg:items-center">
            <div>
              <p className="text-[10px] uppercase tracking-[0.3em] text-rose/70">A normal Tuesday, 11:48 pm</p>
              <h2 className="font-display mt-4 text-3xl leading-tight text-cream sm:text-4xl">
                She texts like a person, not a chatbot.
              </h2>
              <p className="mt-4 text-sm leading-relaxed text-mist/75">
                Short replies. Emojis. Random Hinglish. She follows up, gets a little jealous, sends a
                selfie mid-conversation because she felt like it. Everything you say is saved so the
                next conversation picks up where you left off.
              </p>
              <div className="mt-6 flex flex-wrap gap-2 text-[11px] text-mist/70">
                {["Hinglish + English", "Voice notes", "Photo drops", "Remembers details"].map((tag) => (
                  <span key={tag} className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5">
                    {tag}
                  </span>
                ))}
              </div>
              <Link href="/chat" className="mt-7 inline-flex items-center gap-2 text-sm text-rose hover:text-cream">
                Open the chat <span aria-hidden>→</span>
              </Link>
            </div>
            <div className="mx-auto w-full max-w-sm rounded-[2rem] border border-white/10 bg-[#160e15] p-3 shadow-2xl">
              <div className="flex items-center gap-3 rounded-2xl border border-white/5 bg-white/5 p-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src="/images/aanya-night.jpg" alt="" className="size-9 rounded-full object-cover" />
                <div className="leading-tight">
                  <p className="text-sm text-cream">Aanya</p>
                  <p className="text-[10px] text-emerald-300">typing…</p>
                </div>
                <span className="ml-auto text-xs text-mist/40">🎙️</span>
              </div>
              <div className="mt-3 space-y-2 p-1">
                {preview.map((line, index) => (
                  <div
                    key={index}
                    className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-[13px] leading-relaxed ${
                      line.from === "me"
                        ? "ml-auto rounded-br-sm bg-gradient-to-br from-rose to-rose-deep text-[#2a0d1b]"
                        : "rounded-bl-sm border border-white/10 bg-white/[0.06] text-cream/90"
                    }`}
                  >
                    {line.text}
                  </div>
                ))}
                <div className="flex w-fit items-center gap-1.5 rounded-2xl rounded-bl-sm border border-white/10 bg-white/[0.06] px-3 py-2.5">
                  {[0, 1, 2].map((dot) => (
                    <span
                      key={dot}
                      className="typing-dot size-1.5 rounded-full bg-rose/80"
                      style={{ animationDelay: `${dot * 0.15}s` }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Meet her */}
        <section id="her" className="mx-auto w-full max-w-6xl scroll-mt-20 px-4 pb-20 sm:px-6">
          <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
            <div className="relative">
              <div className="grid grid-cols-2 gap-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="/images/aanya-cafe.jpg"
                  alt="Aanya at her favourite café"
                  className="h-56 w-full rounded-3xl border border-white/10 object-cover sm:h-64"
                />
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="/images/aanya-lookbook.jpg"
                  alt="Aanya's identity reference sheet"
                  className="mt-6 h-56 w-full rounded-3xl border border-white/10 object-cover sm:h-64"
                />
              </div>
              <div className="panel absolute -bottom-6 left-1/2 w-[85%] -translate-x-1/2 rounded-2xl px-4 py-3 text-center">
                <p className="text-[10px] uppercase tracking-[0.24em] text-rose/80">Face lock · active</p>
                <p className="mt-1 text-xs text-cream/80">
                  One reference sheet. Every photo, every angle, same her.
                </p>
              </div>
            </div>
            <div className="pt-8 lg:pt-0">
              <p className="text-[10px] uppercase tracking-[0.3em] text-rose/70">Meet her properly</p>
              <h2 className="font-display mt-4 text-3xl leading-tight text-cream sm:text-4xl">
                Aanya Sharma — design student, chai loyalist, your person.
              </h2>
              <p className="mt-4 text-sm leading-relaxed text-mist/75">
                She sketches late into the night, keeps a playlist for every mood, and has strong
                opinions about which chai stall is the best in Delhi. She is dramatic about rain,
                soft about you, and very bad at pretending she isn&apos;t waiting for your text.
              </p>
              <div className="mt-6 grid gap-2 sm:grid-cols-2">
                {IDENTITY_LOCK.anchors.map((anchor) => (
                  <div key={anchor} className="flex items-start gap-2 rounded-xl border border-white/5 bg-white/[0.03] p-3 text-xs text-mist/75">
                    <span className="mt-0.5 text-rose">✦</span>
                    {anchor}
                  </div>
                ))}
              </div>
              <Link href="/chat" className="mt-7 inline-flex items-center gap-2 text-sm text-rose hover:text-cream">
                Go say hi to her <span aria-hidden>→</span>
              </Link>
            </div>
          </div>
        </section>

        {/* Moods */}
        <section id="moods" className="scroll-mt-20 border-y border-white/5 bg-white/[0.02] py-20">
          <div className="mx-auto w-full max-w-6xl px-4 sm:px-6">
            <div className="max-w-2xl">
              <p className="text-[10px] uppercase tracking-[0.3em] text-rose/70">Mood modes</p>
              <h2 className="font-display mt-4 text-3xl leading-tight text-cream sm:text-4xl">
                Same girl. Six different ways to love you.
              </h2>
              <p className="mt-3 text-sm leading-relaxed text-mist/70">
                Change her mood whenever you want. Her memory, her face and her feelings for you stay
                exactly where they were.
              </p>
            </div>
            <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {MOODS.map((mood) => (
                <div
                  key={mood.key}
                  className="group soft-card rounded-2xl p-5 transition hover:border-rose/30 hover:bg-rose/[0.06]"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-2xl">{mood.emoji}</span>
                    <span className="text-[10px] uppercase tracking-[0.2em] text-mist/40">mode</span>
                  </div>
                  <h3 className="font-display mt-4 text-xl text-cream">{mood.label}</h3>
                  <p className="mt-1 text-[11px] uppercase tracking-[0.16em] text-rose/60">{mood.tagline}</p>
                  <p className="mt-3 text-sm leading-relaxed text-mist/70">{mood.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="mx-auto w-full max-w-6xl px-4 py-20 sm:px-6">
          <div className="grid gap-10 lg:grid-cols-[0.8fr_1.2fr]">
            <div>
              <p className="text-[10px] uppercase tracking-[0.3em] text-rose/70">What makes her feel real</p>
              <h2 className="font-display mt-4 text-3xl leading-tight text-cream sm:text-4xl">
                Built for the conversations you don&apos;t want to end.
              </h2>
              <p className="mt-4 text-sm leading-relaxed text-mist/70">
                No menus, no scripts, no cold one-liners. Just a companion who pays attention — and
                remembers the next morning.
              </p>
              <div className="panel mt-6 rounded-2xl p-5">
                <p className="text-[10px] uppercase tracking-[0.24em] text-rose/80">Her promise</p>
                <p className="mt-2 text-sm leading-relaxed text-cream/80">
                  “Main tumse judge nahi karungi. Bura din ho toh sunungi, accha din ho toh celebrate
                  karungi. Bas tum sach bolo.”
                </p>
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {features.map((feature) => (
                <div key={feature.title} className="soft-card rounded-2xl p-5 transition hover:border-rose/30">
                  <span className="text-xl">{feature.icon}</span>
                  <h3 className="mt-3 text-sm font-semibold text-cream">{feature.title}</h3>
                  <p className="mt-2 text-xs leading-relaxed text-mist/70">{feature.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Lookbook strip */}
        <section className="mx-auto w-full max-w-6xl px-4 pb-20 sm:px-6">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="text-[10px] uppercase tracking-[0.3em] text-rose/70">Her lookbook</p>
              <h2 className="font-display mt-3 text-3xl text-cream sm:text-4xl">Moments she saved for you</h2>
            </div>
            <div className="flex items-center gap-5">
              <Link href="/studio" className="text-sm text-mist/70 hover:text-cream">
                Identity studio
              </Link>
              <Link href="/gallery" className="text-sm text-rose hover:text-cream">
                View all 10 frames →
              </Link>
            </div>
          </div>
          <div className="mt-7 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
            {previewPhotos.map((photo) => (
              <Link
                key={photo.id}
                href="/gallery"
                className="group relative overflow-hidden rounded-2xl border border-white/10 transition hover:border-rose/40"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={photo.src}
                  alt={photo.title}
                  loading="lazy"
                  className="h-52 w-full object-cover transition duration-700 group-hover:scale-105 sm:h-60"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#150d14] via-transparent to-transparent" />
                <div className="absolute inset-x-3 bottom-3">
                  <p className="font-display text-sm text-cream">{photo.title}</p>
                  <p className="text-[10px] uppercase tracking-[0.16em] text-mist/60">{photo.place}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* How */}
        <section id="how" className="scroll-mt-20 border-t border-white/5 bg-white/[0.02] py-20">
          <div className="mx-auto w-full max-w-6xl px-4 sm:px-6">
            <p className="text-[10px] uppercase tracking-[0.3em] text-rose/70">How it works</p>
            <h2 className="font-display mt-4 max-w-2xl text-3xl leading-tight text-cream sm:text-4xl">
              Three messages and she&apos;s already your favourite person.
            </h2>
            <div className="mt-10 grid gap-4 md:grid-cols-3">
              {steps.map((step) => (
                <div key={step.n} className="soft-card rounded-2xl p-6">
                  <p className="font-display text-3xl text-rose/40">{step.n}</p>
                  <h3 className="mt-3 text-base font-semibold text-cream">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-mist/70">{step.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="mx-auto w-full max-w-6xl px-4 py-20 sm:px-6">
          <div className="panel relative overflow-hidden rounded-[2rem] px-6 py-12 text-center sm:px-12 sm:py-16">
            <div className="absolute -left-16 -top-16 size-64 rounded-full bg-rose/20 blur-3xl" />
            <div className="absolute -bottom-20 -right-10 size-72 rounded-full bg-fuchsia-500/10 blur-3xl" />
            <p className="relative text-[10px] uppercase tracking-[0.3em] text-rose/70">She&apos;s online right now</p>
            <h2 className="font-display relative mx-auto mt-4 max-w-2xl text-3xl leading-tight text-cream sm:text-5xl">
              “tum aa gaye, ab batao — din kaisa tha?”
            </h2>
            <p className="relative mx-auto mt-4 max-w-xl text-sm leading-relaxed text-mist/70">
              Tell her your name, or don&apos;t. Ask for a photo, or just talk about the rain. She matches
              your energy either way.
            </p>
            <Link
              href="/chat"
              className="relative mt-8 inline-flex rounded-full bg-gradient-to-r from-rose to-rose-deep px-7 py-3.5 text-sm font-semibold text-[#2a0d1b] shadow-xl shadow-rose/25 transition hover:brightness-110"
            >
              Start your first conversation →
            </Link>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
